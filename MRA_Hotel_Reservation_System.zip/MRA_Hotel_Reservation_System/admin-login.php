<?php
require "config.php";
$error="";
$selectedRole=$_GET["role"]??$_POST["role"]??"";
$roles=[
"Admin"=>["icon"=>"🛡️","desc"=>"Full system control, users, rooms, reservations, payments and settings."],
"Manager"=>["icon"=>"📊","desc"=>"Operations, staff, reservations, reports and guest management."],
"Staff"=>["icon"=>"🧑‍💼","desc"=>"Front desk, check-in/out, room status and housekeeping."],
"Owner"=>["icon"=>"👑","desc"=>"Business performance, revenue, occupancy and reports."]
];
if(!array_key_exists($selectedRole,$roles))$selectedRole="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $selectedRole=$_POST["role"]??"";
    $password=$_POST["password"]??"";
    if(!isset($roles[$selectedRole])) $error="Please select a management role.";
    elseif($password==="") $error="Please enter the password.";
    else {
        try{
            $st=$pdo->prepare("SELECT user_id,customer_id,staff_id,full_name,email,password_hash,role,status FROM users WHERE role=? AND status='Active' ORDER BY user_id DESC LIMIT 1");
            $st->execute([$selectedRole]); $u=$st->fetch();
            if($u && password_verify($password,$u["password_hash"])){
                session_regenerate_id(true); unset($u["password_hash"]); $_SESSION["user"]=$u; redirect("dashboard.php");
            }
            $error="Invalid ".$selectedRole." password.";
        }catch(PDOException $e){
            $error="Database connection error. Import sql/mra_hotel.sql and make sure MySQL is running.";
        }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MRA Hotel | Management Login</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="auth">
<div class="auth-panel"><div class="auth-inner auth-modern">
<a class="auth-brand" href="index.php"><img src="assets/mra-logo.png" alt="MRA Hotel"><span>MRA HOTEL</span></a>
<div class="auth-heading"><span class="eyebrow">PRIVATE MANAGEMENT AREA</span><h1><?= $selectedRole ? "Sign in as ".e($selectedRole)."." : "Management Login." ?></h1><p>Choose the management role. Only the role password is required. Customer accounts cannot access this area.</p></div>
<?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?>
<?php if(!$selectedRole):?>
<div class="role-grid management-role-grid">
<?php foreach($roles as $name=>$info):?><a class="role-card management-role-card" href="admin-login.php?role=<?=urlencode($name)?>"><div class="role-icon"><?=$info["icon"]?></div><h2><?=e($name)?></h2><p><?=e($info["desc"])?></p><span class="btn small">CONTINUE</span></a><?php endforeach;?>
</div>
<?php else:?>
<div class="selected-role"><span class="role-icon"><?=$roles[$selectedRole]["icon"]?></span><div><small>SELECTED ROLE</small><strong><?=e($selectedRole)?></strong></div><a href="admin-login.php" class="btn outline small">CHANGE ROLE</a></div>
<form method="post" class="form auth-form" autocomplete="off">
<input type="hidden" name="role" value="<?=e($selectedRole)?>">
<label>Management Password<input type="password" name="password" placeholder="Enter password" autocomplete="current-password" required autofocus></label>
<button class="btn full auth-submit" type="submit">SIGN IN AS <?=strtoupper(e($selectedRole))?></button>
</form>
<p class="auth-note">Your password is private. Do not share it with customers.</p>
<?php endif;?>
<div class="auth-links"><a href="login.php">Customer Login</a><span>·</span><a href="admin-signup.php">Management Sign Up</a></div>
<a class="back-home" href="index.php">← Back to MRA Hotel</a>
</div></div><div class="auth-image"></div></body></html>