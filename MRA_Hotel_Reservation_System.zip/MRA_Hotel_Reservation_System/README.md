# MRA HOTEL — Complete Database-Driven School Project

## ONE SQL FILE
Import only:
`sql/mra_hotel.sql`

It creates the database, tables, PK/FK relationships, 6 room types, 210 rooms, 620 total capacity, management accounts, facilities, blogs, and supporting tables.

## XAMPP
1. Put this folder in `C:\xampp\htdocs\MRA_Hotel_Fully_Functional`
2. Start Apache and MySQL.
3. Open `http://localhost/phpmyadmin`
4. Import `sql/mra_hotel.sql`
5. Open `http://localhost/MRA_Hotel_Fully_Functional/`

## Demo management accounts
Admin: admin@mrahotel.com / admin123
Manager: manager@mrahotel.com / admin123
Staff: staff@mrahotel.com / admin123
Owner: owner@mrahotel.com / admin123

## Customer
Use Sign Up → Customer Sign Up. The account is created with a hashed password and the customer is logged in after successful registration.

## Account type sign-up
Open `signup-choice.php`.
Customer sign-up is public.
Management sign-up uses authorization code:
`MRA-ADMIN-2026`
For a real hotel this would be controlled by an administrator; the code is included only for the school demo.

## Customer booking
- Select room type
- Select check-in/check-out
- Select adults/children
- Capacity validation
- Double-booking prevention
- Valid ID upload
- Phone camera capture when browser permission is available
- Payment method: Cash, GCash, Card, Bank Transfer, QR Payment
- Automatic total calculation
- Confirmation page
- Booking history
- Payment history
- Notifications
- Review after completed stay

## Admin CRUD
Admin can CREATE, READ, UPDATE, and DELETE:
- Customers
- Rooms
- Reservations
- Payments
Admin also manages staff, reviews, blogs, reports, settings, and room cleaning.

## Staff
View customers, manage reservations, process check-in/check-out, update room status, process/view payments, and mark rooms clean.

## Manager
Manage customers, rooms, reservations, payments, staff, reports, reviews, and blogs.

## Owner
Business reports, revenue, reservations, occupancy, customer statistics, staff overview, and room overview.

## Phone access
A localhost URL only works on the PC running XAMPP. For a phone on the same Wi-Fi:
1. Run `ipconfig` on the PC.
2. Find the PC IPv4 address, e.g. `192.168.1.20`.
3. On the phone open:
`http://192.168.1.20/MRA_Hotel_Fully_Functional/`
4. Allow Apache through Windows Firewall if needed.

For customers outside the Wi-Fi, deploy the PHP/MySQL project to a PHP/MySQL hosting server. A localhost link is not a public internet link.

## Security notes
Passwords use password hashing. Customer ID images are stored under `uploads/` and `.htaccess` denies direct web access on Apache. Only authorized management pages query sensitive customer ID information.

## School deliverables
- Entities and attributes
- ER diagram
- Primary and foreign keys
- 1NF, 2NF, 3NF documentation
- Five CRUD SQL examples
- Working database-backed PHP system
- Responsive hotel UI
- Role-based access


## Final booking notes
- Booking requires valid ID type, ID number, and ID photo.
- Customers can upload an ID image or use device camera capture where the browser permits camera access.
- Booking rules must be accepted before confirmation.
- Gallery is view-only; booking is available from room details/booking flow.
- Management demo credentials are intentionally not displayed on public login pages.
- Email confirmation uses PHP mail(); XAMPP must be configured with an SMTP/mail service for actual email delivery. In-system notifications work through the database.


## FINAL LOGIN DEMO CREDENTIALS
Customer:
- Email: juan.demo@mrahotel.com
- Password: admin123

Management access gate:
- Password: 1234

Management role passwords:
- Admin: 12345
- Manager: 12345
- Staff: 12345
- Owner: 2468

Management demo emails:
- admin@mrahotel.com
- manager@mrahotel.com
- staff@mrahotel.com
- owner@mrahotel.com

Management sign-up authorization code:
- 1234

Note: These simple passwords are for the school-project demo. For a real hotel deployment, use strong unique passwords and HTTPS.


## FINAL FIXES IN THIS VERSION
- Management login shows Admin / Manager / Staff / Owner choices directly; no demo access password is displayed.
- Management role login uses password only (no work email/username field).
- Flexible check-in/check-out: customer selects dates only; no fixed time field.
- Booking calculates number of nights automatically.
- ID upload supports phone camera capture/fallback upload.
- GCash and QR Payment show a real scannable demo QR image; Card and Bank Transfer show their payment panels.
- Dining menu contains 10 Breakfast, 10 Lunch, 10 Dinner, 20 Dessert, 20 Snacks, and 10 Drinks items with photos and prices.
- Executive Room and Fitness Gym image fallbacks were strengthened.
- Public Reviews page shows the complete 128-review demo list.
- Owner/Manager/Staff/Admin dashboards have proper sidebar choices.
- Revenue cards use a safer COALESCE query.
- Mobile navigation/dashboard layouts were polished for phone screens.


## Final fixes in this build
- Customer login accepts email or contact number and redirects directly to the customer dashboard.
- Customer signup creates the customer and login account in one transaction and signs the customer in immediately.
- Management role selection remains private: Admin, Manager, Staff, or Owner is selected before the password field.
- Management dashboard sidebars include Quick Access and all sections have a Back to Dashboard control.
- Staff Today's Operations shows live counts for today's check-ins, check-outs, and cleaning tasks.
- Booking lets the customer choose both check-in and check-out date/time; the stay duration and 24-hour billing blocks are calculated automatically.
- Facility detail pages rotate their main images and allow thumbnail selection.
- Blog cards now have View Article pages.
