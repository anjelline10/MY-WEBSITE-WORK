<?php
require "config.php";
$id=(int)($_GET['id']??0);
$s=$pdo->prepare("SELECT rt.*, COUNT(rm.room_id) AS total_rooms, SUM(rm.status='Available') AS available_rooms FROM room_types rt LEFT JOIN rooms rm ON rm.room_type_id=rt.room_type_id WHERE rt.room_type_id=? GROUP BY rt.room_type_id");
$s->execute([$id]);$r=$s->fetch();if(!$r) die("Room type not found.");
$photos = [
  1=>["https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1400&q=85","https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=85","https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&w=1200&q=85"],
  2=>["https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=1400&q=85","https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=85","https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1200&q=85"],
  3=>["https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=1400&q=85","https://images.unsplash.com/photo-1560185127-6a8c4b2f5d8d?auto=format&fit=crop&w=1200&q=85","https://images.unsplash.com/photo-1578898887932-dce23a595ad4?auto=format&fit=crop&w=1200&q=85"],
  4=>["https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1400&q=85","https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=85","https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=1200&q=85"],
  5=>["https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1400&q=90","https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=1200&q=90","https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1200&q=90"],
  6=>["https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=1400&q=85","https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=85","https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=85"]
];
$roomPhotos=$photos[$id]??[$r['image_url']];
$breakfastIncluded=in_array($id,[5,6]);
$amenityList=array_filter(array_map('trim',preg_split('/[,|]/',$r['amenities'])));
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($r['type_name'])?> | MRA Hotel</title><link rel="stylesheet" href="assets/style.css"></head><body>
<header class="site-header"><a class="brand" href="index.php"><img class="brand-logo" src="assets/mra-logo.png" alt="MRA Hotel Logo"><span>MRA HOTEL</span></a><nav><a href="index.php">Home</a><a href="rooms.php">Rooms</a><a href="gallery.php">Gallery</a><a href="login.php">Login</a></nav></header>
<main class="section room-detail-page">
<p class="eyebrow">ROOM DETAILS</p><h1><?=e($r['type_name'])?></h1>
<div class="photo-gallery">
  <div class="main-photo"><img id="mainRoomPhoto" src="<?=e($roomPhotos[0])?>" alt="<?=e($r['type_name'])?>" onerror="this.src='https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1400&q=90'"></div>
  <div class="thumbs"><?php foreach($roomPhotos as $i=>$im): ?><button type="button" class="thumb <?= $i===0?'active':'' ?>" onclick="showRoomPhoto(this,'<?=e($im)?>')"><img src="<?=e($im)?>" alt="Room photo <?=($i+1)?>"></button><?php endforeach;?></div>
</div>
<div class="room-detail-grid">
<section>
  <p class="lead"><?=e($r['description'])?></p>
  <div class="detail-grid"><div><b>Room Size</b><span><?=e($r['size_sqm'])?> sqm</span></div><div><b>Bed</b><span><?=e($r['bed_type'])?></span></div><div><b>Capacity</b><span><?=e($r['capacity'])?> guests</span></div><div><b>Available</b><span><?=e($r['available_rooms'])?> rooms</span></div></div>
  <h2 class="subheading">What's inside the room?</h2>
  <div class="amenity-list"><?php foreach($amenityList as $a): ?><span>✓ <?=e($a)?></span><?php endforeach; ?><span>✓ Towels & toiletries</span><span>✓ Daily housekeeping</span></div>
  <h2 class="subheading">Stay benefits</h2>
  <div class="included-box"><p>✓ Free Wi-Fi</p><p>✓ Swimming pool access</p><p>✓ Gym access</p><p>✓ Basic toiletries</p><?php if($breakfastIncluded): ?><p class="breakfast">✓ <b>FREE BREAKFAST INCLUDED</b></p><?php else: ?><p>Breakfast available at the dining area for an additional charge.</p><?php endif;?></div>
</section>
<aside class="booking-summary card"><span class="pill"><?=e($r['type_name'])?></span><h2><?=money($r['price_per_night'])?> <small>/ night</small></h2><p class="muted"><b>Flexible check-in and check-out:</b> choose your preferred arrival and departure times on the booking form. Availability is confirmed by the hotel.</p><p class="muted">Your booking page calculates the exact number of nights and estimated stay duration from your selected dates and times.</p><a class="btn full" href="book.php?type=<?=$r['room_type_id']?>">BOOK THIS ROOM</a><a class="btn outline full" href="rooms.php">Back to Rooms</a></aside>
</div>
</main>
<script>
function showRoomPhoto(btn,url){document.getElementById('mainRoomPhoto').src=url;document.querySelectorAll('.thumb').forEach(x=>x.classList.remove('active'));btn.classList.add('active');}
</script>
</body></html>