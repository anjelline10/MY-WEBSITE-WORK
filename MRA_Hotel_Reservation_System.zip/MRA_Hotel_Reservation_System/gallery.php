<?php
require "config.php";
$rooms = $pdo->query("SELECT rt.*, COUNT(r.room_id) AS total_rooms, SUM(r.status='Available') AS available_rooms
    FROM room_types rt LEFT JOIN rooms r ON r.room_type_id=rt.room_type_id
    GROUP BY rt.room_type_id ORDER BY rt.room_type_id")->fetchAll();
$galleryImages = [
  1 => [
    "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&w=1200&q=85"
  ],
  2 => [
    "https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1200&q=85"
  ],
  3 => [
    "https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1560185127-6a8c4b2f5d8d?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1578898887932-dce23a595ad4?auto=format&fit=crop&w=1200&q=85"
  ],
  4 => [
    "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=1200&q=85"
  ],
  5 => [
    "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1590490359683-658d3d23f972?auto=format&fit=crop&w=1200&q=85"
  ],
  6 => [
    "https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=85"
  ]
];
$breakfastIncluded = [5,6]; // complimentary breakfast for higher room categories
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Room Gallery | MRA Hotel</title><link rel="stylesheet" href="assets/style.css"></head><body>
<header class="site-header"><a class="brand" href="index.php"><img class="brand-logo" src="assets/mra-logo.png" alt="MRA Hotel Logo"><span>MRA HOTEL</span></a><nav><a href="index.php">Home</a><a href="rooms.php">Rooms</a><a href="amenities.php">Amenities</a><a href="facilities.php">Facilities</a><a href="dining.php">Dining</a><a href="about.php">About Us</a><a href="gallery.php">Gallery</a><a href="reviews.php">Reviews</a><a href="blog.php">Blog</a><a href="location.php">Location</a><a href="contact.php">Contact</a><a href="login.php">Login</a><a href="signup.php">Sign Up</a></nav></header>
<main class="section">
<p class="eyebrow">ROOM GALLERY</p><h1>See every room before you book.</h1>
<p class="lead muted">The gallery is for viewing only. Open any room to explore its photos, bed arrangement, room size, amenities, guest capacity, availability, and stay inclusions before making a reservation.</p>
<div class="room-gallery-grid">
<?php foreach($rooms as $r): $imgs=$galleryImages[(int)$r['room_type_id']]??[$r['image_url']]; ?>
<article class="room-gallery-card">
  <div class="gallery-cover"><a href="room.php?id=<?=$r['room_type_id']?>"><img src="<?=e($imgs[0])?>" alt="<?=e($r['type_name'])?>"></a><span class="photo-count"><?=count($imgs)?> photos</span></div>
  <div class="room-body">
    <span class="pill"><?=e($r['type_name'])?></span>
    <h2><?=e($r['type_name'])?></h2>
    <p class="muted"><?=e($r['size_sqm'])?> sqm · <?=e($r['bed_type'])?> · up to <?=e($r['capacity'])?> guests</p>
    <div class="mini-amenities"><span>Wi-Fi</span><span>Aircon</span><span>Private Bath</span><?php if(in_array((int)$r['room_type_id'],$breakfastIncluded)): ?><span>Free Breakfast</span><?php endif;?></div>
    <h3><?=money($r['price_per_night'])?> <small>/ night</small></h3>
    <p><b><?=e($r['available_rooms'])?></b> rooms available now</p>
    <div class="actions"><a class="btn small" href="room.php?id=<?=$r['room_type_id']?>">VIEW FULL ROOM</a></div>
  </div>
</article>
<?php endforeach; ?>
</div>
</main><footer><div><b>MRA HOTEL</b><p>Stay. Relax. Experience MRA.</p></div><div><b>Contact</b><p>MRA Hotel Avenue<br>(02) 8123-4567<br>0917-000-0000<br>reservations@mrahotel.com</p></div><div><b>Social</b><p>Facebook · Instagram · TikTok · Messenger</p></div></footer></body></html>