<?php
require "config.php";
$id=(int)($_GET["id"]??0);
$s=$pdo->prepare("SELECT * FROM blogs WHERE blog_id=? AND status='Published'");
$s->execute([$id]);$b=$s->fetch();
if(!$b){http_response_code(404);exit("Article not found.");}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($b["title"])?> | MRA Hotel</title><link rel="stylesheet" href="assets/style.css"></head><body>
<header class="site-header"><a class="brand" href="index.php"><img class="brand-logo" src="assets/mra-logo.png" alt="MRA Hotel Logo"><span>MRA HOTEL</span></a><nav><a href="index.php">Home</a><a href="rooms.php">Rooms</a><a href="amenities.php">Amenities</a><a href="facilities.php">Facilities</a><a href="dining.php">Dining</a><a href="about.php">About Us</a><a href="gallery.php">Gallery</a><a href="reviews.php">Reviews</a><a href="blog.php">Blog</a><a href="location.php">Location</a><a href="contact.php">Contact</a><a href="login.php">Login</a><a href="signup.php">Sign Up</a></nav></header>
<main class="section article-page"><p class="eyebrow">MRA HOTEL BLOG</p><h1><?=e($b["title"])?></h1><p class="muted"><?=e($b["published_at"])?> · <?=e($b["author"])?></p><img class="article-hero" src="<?=e($b["image_url"])?>" alt="<?=e($b["title"])?>"><article class="article-content"><p><?=nl2br(e($b["content"]))?></p></article><a class="btn" href="blog.php">← Back to Blog</a></main>
<footer><div><b>MRA HOTEL</b><p>Stay. Relax. Experience MRA.</p></div><div><b>Contact</b><p>MRA Hotel Avenue<br>(02) 8123-4567<br>0917-000-0000<br>reservations@mrahotel.com</p></div><div><b>Social</b><p>Facebook · Instagram · TikTok · Messenger</p></div></footer></body></html>