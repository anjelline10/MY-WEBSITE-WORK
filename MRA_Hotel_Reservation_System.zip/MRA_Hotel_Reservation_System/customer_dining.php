<?php
require "config.php"; require_login(["Customer"]);
$menus = [
'Breakfast'=>[
['Classic Filipino Breakfast','Longganisa, eggs, garlic rice and fruit',320,'https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?auto=format&fit=crop&w=900&q=85'],
['American Breakfast','Eggs, bacon, toast, potatoes and fruit',350,'https://images.unsplash.com/photo-1504754524776-8f4f37790ca0?auto=format&fit=crop&w=900&q=85'],
['Pancake Stack','Fluffy pancakes, berries and maple syrup',250,'https://images.unsplash.com/photo-1528207776546-365bb710ee93?auto=format&fit=crop&w=900&q=85'],
['Continental Breakfast','Bread, pastries, fruit, yogurt and coffee',380,'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=900&q=85'],
['Eggs Benedict','Poached eggs, muffin and hollandaise',390,'https://images.unsplash.com/photo-1608039829572-78524f79c4c7?auto=format&fit=crop&w=900&q=85'],
['Waffles & Berries','Crispy waffles with cream and berries',280,'https://images.unsplash.com/photo-1562376552-0d160a2f2386?auto=format&fit=crop&w=900&q=85'],
['Breakfast Burrito','Egg, cheese, vegetables and savory filling',300,'https://images.unsplash.com/photo-1626700051175-6818013e1d4f?auto=format&fit=crop&w=900&q=85'],
['French Toast','Brioche toast with fruit and syrup',270,'https://images.unsplash.com/photo-1484723091739-30a097e8f929?auto=format&fit=crop&w=900&q=85'],
['Omelette Plate','Three-egg omelette with vegetables and toast',290,'https://images.unsplash.com/photo-1510693206972-df098f0cbf7c?auto=format&fit=crop&w=900&q=85'],
['Granola Yogurt Bowl','Greek yogurt, granola, honey and fresh fruit',230,'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=900&q=85'],
],
'Lunch'=>[
['Chicken Alfredo Pasta','Creamy pasta with grilled chicken and herbs',320,'https://images.unsplash.com/photo-1551892374-ecf8754cf8b0?auto=format&fit=crop&w=900&q=85'],
['Club Sandwich','Triple-layer sandwich with fries and salad',280,'https://images.unsplash.com/photo-1553909489-cd47e0907980?auto=format&fit=crop&w=900&q=85'],
['Beef Burger & Fries','Premium beef patty, cheese and fries',350,'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=85'],
['Chicken Rice Bowl','Grilled chicken, rice, vegetables and sauce',290,'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=85'],
['Caesar Salad','Romaine, parmesan and Caesar dressing',260,'https://images.unsplash.com/photo-1546793665-c74683f339c1?auto=format&fit=crop&w=900&q=85'],
['Fish & Chips','Crispy fish, fries and tartar sauce',360,'https://images.unsplash.com/photo-1579208030886-b937da0925dc?auto=format&fit=crop&w=900&q=85'],
['Beef Tapa Bowl','Tender beef tapa, garlic rice and egg',330,'https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=900&q=85'],
['Chicken Teriyaki','Grilled chicken, rice and sesame vegetables',310,'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=85'],
['Margherita Pizza','Tomato, mozzarella and fresh basil',340,'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=900&q=85'],
['Seafood Fried Rice','Fragrant rice with shrimp, squid and egg',300,'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=900&q=85'],
],
'Dinner'=>[
['Grilled Salmon','Salmon, vegetables and lemon butter',520,'https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=900&q=85'],
['Steak Dinner','Tender steak with potatoes and vegetables',650,'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=900&q=85'],
['Creamy Seafood Pasta','Seafood pasta in a rich creamy sauce',390,'https://images.unsplash.com/photo-1563379926898-05f4575a45d8?auto=format&fit=crop&w=900&q=85'],
['Filipino Dinner Platter','Chef\'s selection of Filipino favorites',450,'https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=900&q=85'],
['Roast Chicken Dinner','Herb-roasted chicken with vegetables and rice',420,'https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=900&q=85'],
['Beef Kare-Kare','Slow-cooked beef with peanut sauce and vegetables',480,'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=85'],
['Chicken Inasal','Grilled marinated chicken with rice',390,'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=85'],
['Seafood Paella','Rice with shrimp, mussels and squid',560,'https://images.unsplash.com/photo-1534080564583-6be75777b70a?auto=format&fit=crop&w=900&q=85'],
['Truffle Mushroom Pasta','Creamy mushroom pasta with truffle aroma',430,'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=900&q=85'],
['Roast Beef Plate','Slow-roasted beef with vegetables and gravy',590,'https://images.unsplash.com/photo-1600891964092-4316c288032e?auto=format&fit=crop&w=900&q=85'],
],
'Dessert'=>[
['Chocolate Lava Cake','Warm chocolate cake with vanilla ice cream',220,'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=900&q=85'],
['Mango Cheesecake','Creamy cheesecake with fresh mango',230,'https://images.unsplash.com/photo-1565958011703-44f9829ba187?auto=format&fit=crop&w=900&q=85'],
['Fruit Parfait','Yogurt, granola and seasonal fruit',190,'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=900&q=85'],
['Ice Cream Trio','Three scoops with hotel toppings',180,'https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=900&q=85'],
['Classic Tiramisu','Coffee-soaked mascarpone dessert',240,'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=900&q=85'],
['Strawberry Shortcake','Vanilla sponge, cream and strawberries',220,'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?auto=format&fit=crop&w=900&q=85'],
['Creme Brulee','Silky custard with caramelized sugar',210,'https://images.unsplash.com/photo-1470324161839-ce2bb6fa6bc3?auto=format&fit=crop&w=900&q=85'],
['Blueberry Cheesecake','Creamy cheesecake with blueberry topping',230,'https://images.unsplash.com/photo-1524351199678-941a58a3df50?auto=format&fit=crop&w=900&q=85'],
['Churros','Cinnamon churros with chocolate dip',190,'https://images.unsplash.com/photo-1624371414361-e670edf4898d?auto=format&fit=crop&w=900&q=85'],
['Banana Split','Banana, ice cream, chocolate and nuts',210,'https://images.unsplash.com/photo-1501443762994-82bd5dace89a?auto=format&fit=crop&w=900&q=85'],
['Panna Cotta','Vanilla panna cotta with berry sauce',220,'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=900&q=85'],
['Apple Crumble','Warm apple crumble with vanilla ice cream',200,'https://images.unsplash.com/photo-1568571780765-9276ac8b75a0?auto=format&fit=crop&w=900&q=85'],
['Mango Float','Creamy mango dessert with biscuits',190,'https://images.unsplash.com/photo-1623065422902-30a2d299bbe4?auto=format&fit=crop&w=900&q=85'],
['Red Velvet Slice','Red velvet cake with cream cheese frosting',230,'https://images.unsplash.com/photo-1586788680434-30d324b2d46f?auto=format&fit=crop&w=900&q=85'],
['Lemon Tart','Tangy lemon curd with buttery crust',210,'https://images.unsplash.com/photo-1519915028121-7d3463d20b13?auto=format&fit=crop&w=900&q=85'],
['Caramel Flan','Silky caramel custard',190,'https://images.unsplash.com/photo-1551024506-0bccd828d307?auto=format&fit=crop&w=900&q=85'],
['Coconut Pudding','Coconut pudding with toasted coconut',180,'https://images.unsplash.com/photo-1490474418585-ba9bad8fd0ea?auto=format&fit=crop&w=900&q=85'],
['Chocolate Mousse','Silky chocolate mousse with cocoa',210,'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=900&q=85'],
['Mixed Berry Tart','Fresh berries over pastry cream',230,'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=900&q=85'],
['Warm Brownie','Chocolate brownie with vanilla ice cream',200,'https://images.unsplash.com/photo-1564355808539-22f7d6d0c8f4?auto=format&fit=crop&w=900&q=85'],
],
'Snacks'=>[
['French Fries','Crispy fries with house dip',150,'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=900&q=85'],
['Chicken Wings','Crispy wings with your choice of sauce',260,'https://images.unsplash.com/photo-1527477396000-e27163b481c2?auto=format&fit=crop&w=900&q=85'],
['Nachos','Tortilla chips with cheese and salsa',240,'https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?auto=format&fit=crop&w=900&q=85'],
['Clubhouse Bites','Mini sandwiches with fries',250,'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=900&q=85'],
['Cheese Platter','Assorted cheese, crackers and fruit',360,'https://images.unsplash.com/photo-1452195100486-9cc805987862?auto=format&fit=crop&w=900&q=85'],
['Spring Rolls','Crispy vegetable spring rolls with dip',180,'https://images.unsplash.com/photo-1548507200-4f9c5f4c4d65?auto=format&fit=crop&w=900&q=85'],
['Mozzarella Sticks','Crispy cheese sticks with marinara',220,'https://images.unsplash.com/photo-1531749668029-2db88e4276c7?auto=format&fit=crop&w=900&q=85'],
['Calamari Bites','Crispy calamari with lemon aioli',280,'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=900&q=85'],
['Garlic Bread','Toasted garlic bread with herbs',160,'https://images.unsplash.com/photo-1619535860434-cf9b2c5b5d2d?auto=format&fit=crop&w=900&q=85'],
['Mini Sliders','Three beef sliders with cheese',290,'https://images.unsplash.com/photo-1521305916504-4a1121188589?auto=format&fit=crop&w=900&q=85'],
['Popcorn Chicken','Crispy chicken bites with dip',240,'https://images.unsplash.com/photo-1562967916-eb82221dfb92?auto=format&fit=crop&w=900&q=85'],
['Potato Wedges','Seasoned wedges with sour cream dip',170,'https://images.unsplash.com/photo-1518013431117-eb1465fa5752?auto=format&fit=crop&w=900&q=85'],
['Edamame','Steamed edamame with sea salt',160,'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=85'],
['Fruit Cup','Fresh seasonal fruit cup',180,'https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=900&q=85'],
['Trail Mix','Nuts, dried fruit and chocolate',170,'https://images.unsplash.com/photo-1599599810694-57a9d7e9b4b0?auto=format&fit=crop&w=900&q=85'],
['Tuna Sandwich','Tuna salad sandwich with greens',230,'https://images.unsplash.com/photo-1553909489-cd47e0907980?auto=format&fit=crop&w=900&q=85'],
['Chicken Quesadilla','Grilled chicken and cheese quesadilla',260,'https://images.unsplash.com/photo-1618040996337-56904b7850b9?auto=format&fit=crop&w=900&q=85'],
['Vegetable Tempura','Crispy vegetables with dipping sauce',240,'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=85'],
['Onion Rings','Crispy onion rings with house sauce',180,'https://images.unsplash.com/photo-1639024471283-03518883512d?auto=format&fit=crop&w=900&q=85'],
['Pretzel Bites','Warm pretzel bites with cheese dip',190,'https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?auto=format&fit=crop&w=900&q=85'],
],
'Drinks'=>[
['House Coffee','Freshly brewed hotel coffee',150,'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=900&q=85'],
['Fresh Mango Juice','Freshly blended mango juice',180,'https://images.unsplash.com/photo-1546173159-315724a31696?auto=format&fit=crop&w=900&q=85'],
['Iced Tea','Refreshing house iced tea',140,'https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=900&q=85'],
['Fruit Shake','Fresh seasonal fruit shake',190,'https://images.unsplash.com/photo-1502741338009-cac2772e18bc?auto=format&fit=crop&w=900&q=85'],
['Sparkling Water','Chilled sparkling water',120,'https://images.unsplash.com/photo-1559825481-12a05cc00344?auto=format&fit=crop&w=900&q=85'],
['Hot Chocolate','Rich chocolate drink with foam',170,'https://images.unsplash.com/photo-1542990253-0b9c1d8a0f7a?auto=format&fit=crop&w=900&q=85'],
['Cappuccino','Espresso with steamed milk foam',170,'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=900&q=85'],
['Matcha Latte','Creamy matcha with milk',190,'https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&w=900&q=85'],
['Lemonade','Fresh lemon drink with mint',150,'https://images.unsplash.com/photo-1621263764928-df1444c5f0e1?auto=format&fit=crop&w=900&q=85'],
['Cola','Chilled bottled soft drink',120,'https://images.unsplash.com/photo-1629203849820-fdd70d49c38e?auto=format&fit=crop&w=900&q=85'],
],
];
if(!isset($_SESSION["food_cart"]))$_SESSION["food_cart"]=[];
$msg="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $action=$_POST["action"]??"";
    if($action==="add"){
        $key=(string)($_POST["key"]??""); $cat=$_POST["category"]??"";
        if(isset($menus[$cat]) && isset($menus[$cat][(int)$key])){
            $item=$menus[$cat][(int)$key]; $cartKey=$cat."|".$key;
            $qty=max(1,min(10,(int)($_POST["qty"]??1)));
            $_SESSION["food_cart"][$cartKey]=["category"=>$cat,"name"=>$item[0],"price"=>$item[2],"qty"=>$qty,"image"=>$item[3]];
            $msg=$item[0]." added to your order.";
        }
    } elseif($action==="remove"){unset($_SESSION["food_cart"][$_POST["cart_key"]??""]);$msg="Item removed.";}
    elseif($action==="clear"){$_SESSION["food_cart"]=[];$msg="Dining order cleared.";}
}
$total=0;foreach($_SESSION["food_cart"] as $it)$total += $it["price"]*$it["qty"];
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dining Order | MRA Hotel</title><link rel="stylesheet" href="assets/style.css"></head>
<body><header class="site-header"><a class="brand" href="customer-dashboard.php"><img class="brand-logo" src="assets/mra-logo.png" alt="MRA Hotel"><span>MRA HOTEL</span></a><nav><a href="customer-dashboard.php">Dashboard</a><a href="customer_reservations.php">Reservations</a><a href="customer_rooms.php">Rooms</a><a href="customer_dining.php">Dining</a><a href="logout.php">Logout</a></nav></header>
<main class="dashboard"><div class="sidebar-layout"><aside class="sidebar"><a href="customer-dashboard.php">🏠 Dashboard</a><a href="customer_reservations.php">📅 My Reservations</a><a href="customer_rooms.php">🛏️ Available Rooms</a><a class="active" href="customer_dining.php">🍽️ Dining & Order Food</a><a href="customer_payments.php">💳 My Payments</a><a href="customer_profile.php">📋 My Profile</a><a href="customer_reviews.php">⭐ Reviews</a><a href="customer_notifications.php">🔔 Notifications</a></aside>
<section><div class="dining-header"><div><p class="eyebrow">MRA HOTEL DINING</p><h1>Order food for your stay.</h1><p class="lead">Choose breakfast, lunch, dinner, dessert, snacks, or drinks. Add items to your order and see the total automatically.</p></div><div class="cart-total"><small>ORDER TOTAL</small><strong>₱<?=number_format($total,2)?></strong></div></div>
<?php if($msg):?><div class="success"><?=e($msg)?></div><?php endif;?>
<div class="dining-tabs"><?php $first=true;foreach($menus as $cat=>$items):?><button class="dining-tab <?=$first?'active':''?>" data-target="<?=e($cat)?>"><?=e($cat)?></button><?php $first=false;endforeach;?></div>
<?php $first=true;foreach($menus as $cat=>$items):?><section id="menu-<?=e($cat)?>" class="dining-section <?=$first?'active':''?>"><div class="food-grid"><?php foreach($items as $i=>$item):?><article class="food-card"><img src="<?=e($item[3])?>" alt="<?=e($item[0])?>" loading="lazy"><div class="food-body"><span class="pill"><?=e($cat)?></span><h3><?=e($item[0])?></h3><p><?=e($item[1])?></p><strong>₱<?=number_format($item[2],2)?></strong><form method="post" class="food-order-form"><input type="hidden" name="action" value="add"><input type="hidden" name="category" value="<?=e($cat)?>"><input type="hidden" name="key" value="<?=$i?>"><label>Qty <input type="number" name="qty" min="1" max="10" value="1"></label><button class="btn small" type="submit">ADD TO ORDER</button></form></div></article><?php endforeach;?></div></section><?php $first=false;endforeach;?>
<div class="panel order-panel"><div class="dining-heading"><div><p class="eyebrow">YOUR ORDER</p><h2>Selected Food</h2></div><form method="post"><input type="hidden" name="action" value="clear"><button class="btn outline small">CLEAR</button></form></div>
<?php if(!$_SESSION["food_cart"]):?><p class="muted">No food selected yet. Choose a menu item above.</p><?php else:?><div class="table-wrap"><table><tr><th>Item</th><th>Category</th><th>Qty</th><th>Price</th><th>Total</th><th></th></tr><?php foreach($_SESSION["food_cart"] as $key=>$it):?><tr><td><?=e($it["name"])?></td><td><?=e($it["category"])?></td><td><?=$it["qty"]?></td><td>₱<?=number_format($it["price"],2)?></td><td>₱<?=number_format($it["price"]*$it["qty"],2)?></td><td><form method="post"><input type="hidden" name="action" value="remove"><input type="hidden" name="cart_key" value="<?=e($key)?>"><button class="btn tiny">Remove</button></form></td></tr><?php endforeach;?></table><div class="order-total">Total: <b>₱<?=number_format($total,2)?></b></div><button class="btn" type="button" onclick="alert('Dining order prepared for confirmation. This school-project demo shows the selected items and total.')">CONFIRM DINING ORDER</button></div><?php endif;?></div>
</section></div></main>
<script>document.querySelectorAll('.dining-tab').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.dining-tab').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.dining-section').forEach(x=>x.classList.remove('active'));btn.classList.add('active');document.getElementById('menu-'+btn.dataset.target).classList.add('active')}));</script>
</body></html>