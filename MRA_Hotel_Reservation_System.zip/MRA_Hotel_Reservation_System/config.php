<?php
// MRA Hotel - MySQL configuration
session_start();
$host = "localhost";
$db   = "mra_hotel";
$user = "root";
$pass = "";
$charset = "utf8mb4";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die("Database connection failed. Import sql/mra_hotel.sql first, then check config.php.");
}
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function is_logged(){ return isset($_SESSION['user']); }
function role(){ return $_SESSION['user']['role'] ?? null; }
function require_login($roles=[]){
    if (!is_logged()) { header("Location: login.php"); exit; }
    if ($roles && !in_array(role(), $roles, true)) { http_response_code(403); die("Access denied."); }
}
function money($n){ return "₱".number_format((float)$n,2); }
function redirect($url){ header("Location: $url"); exit; }
?>