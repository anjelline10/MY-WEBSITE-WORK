<?php
require "config.php";
$baseNames=["Angel Labrado","Juan Dela Cruz","Maria Santos","Liam Garcia","Ava Mendoza","Sofia Reyes","Miguel Cruz","Nicole Flores","Daniel Ramos","Chloe Garcia","Ethan Torres","Mia Santos","Lucas Rivera","Isabella Cruz","Noah Mendoza","Ella Reyes","Gabriel Santos","Leah Garcia","Nathan Flores","Amelia Cruz","James Ramos","Grace Mendoza","Adrian Reyes","Hannah Santos","Caleb Garcia","Zoe Flores","Marco Cruz","Maya Ramos","Luis Mendoza","Claire Reyes","Ryan Santos","Nina Garcia"];
$comments=[
"The room was spotless, comfortable, and beautifully prepared. The staff were warm and helpful.",
"Booking was easy and the hotel atmosphere felt calm and welcoming from arrival to departure.",
"The pool and gym were excellent, and the dining choices made our stay very convenient.",
"Comfortable bed, clean bathroom, reliable Wi-Fi, and thoughtful service throughout the stay.",
"We enjoyed the room design and the restaurant. Everything felt polished and well organized.",
"The front desk team was professional and friendly. We would gladly stay at MRA Hotel again.",
"Great experience for a short stay. The room was quiet, clean, and exactly as described.",
"Breakfast was delicious and the hotel facilities were easy to access.",
"The reservation process was smooth and the staff answered our questions quickly.",
"A relaxing stay with comfortable rooms and a lovely boutique-hotel atmosphere."
];
$demoReviews=[];
$ratings=array_merge(array_fill(0,90,5),array_fill(0,32,4),array_fill(0,5,3),[2]);
for($i=0;$i<128;$i++){
    $demoReviews[]=["name"=>$baseNames[$i%count($baseNames)],"rating"=>$ratings[$i],"text"=>$comments[$i%count($comments)],"room"=>["Standard Room","Deluxe Room","Twin Room","Family Room","Executive Room","Suite"][$i%6],"date"=>date("M d, Y",strtotime("-".$i." days"))];
}
try{
 $rs=$pdo->query("SELECT rv.*,CONCAT(c.first_name,' ',c.last_name) customer FROM reviews rv JOIN customers c ON c.customer_id=rv.customer_id WHERE rv.review_status='Approved' ORDER BY rv.created_at DESC")->fetchAll();
}catch(Throwable $e){$rs=[];}
$display=array_slice($demoReviews,0,max(0,128-count($rs)));
foreach($rs as $r){
    if(count($display)>=128) break;
    $display[]=["name"=>$r["customer"],"rating"=>(int)$r["rating"],"text"=>$r["review_text"],"room"=>"Verified Guest","date"=>date("M d, Y",strtotime($r["created_at"]))];
}
$avg=4.6;$count=128;
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reviews | MRA Hotel</title><link rel="stylesheet" href="assets/style.css"></head>
<body><header class="site-header"><a class="brand" href="index.php"><img class="brand-logo" src="assets/mra-logo.png" alt="MRA Hotel"><span>MRA HOTEL</span></a><nav><a href="index.php">Home</a><a href="rooms.php">Rooms</a><a href="amenities.php">Amenities</a><a href="facilities.php">Facilities</a><a href="dining.php">Dining</a><a href="about.php">About Us</a><a href="gallery.php">Gallery</a><a href="reviews.php">Reviews</a><a href="blog.php">Blog</a><a href="location.php">Location</a><a href="contact.php">Contact</a><a href="login.php">Login</a><a class="btn tiny" href="signup.php">Sign Up</a></nav></header>
<main class="section"><p class="eyebrow">GUEST REVIEWS</p><h1>Real stays. Real experiences.</h1>
<div class="review-overview"><div><span class="review-score"><?=e($avg)?></span><div class="stars">★★★★★</div><p class="muted">Based on <?=e($count)?> guest reviews</p></div><div class="rating-bars"><div>5 ★ <span><i style="width:70%"></i></span> 70%</div><div>4 ★ <span><i style="width:25%"></i></span> 25%</div><div>3 ★ <span><i style="width:4%"></i></span> 4%</div><div>2 ★ <span><i style="width:1%"></i></span> 1%</div><div>1 ★ <span><i style="width:0%"></i></span> 0%</div></div></div>
<div class="review-toolbar"><b>All <?=count($display)?> guest reviews</b><span class="muted">Showing the complete review list for this demo.</span></div>
<div class="review-grid">
<?php foreach($display as $r):?><article class="review-card"><div class="review-top"><b><?=e($r["name"])?></b><span class="pill"><?=e($r["room"])?></span></div><div class="stars"><?=str_repeat("★",$r["rating"]).str_repeat("☆",5-$r["rating"])?></div><p><?=e($r["text"])?></p><small><?=e($r["date"])?></small></article><?php endforeach;?>
</div></main><footer><div><img class="brand-logo" src="assets/mra-logo.png" alt="MRA Hotel"><p>Stay. Relax. Experience MRA.</p></div><div><b>Contact</b><p>MRA Hotel Avenue<br>(02) 8123-4567<br>0917-000-0000<br>reservations@mrahotel.com</p></div><div><b>Social</b><p>Facebook · Instagram · TikTok · Messenger</p></div></footer></body></html>