<?php
require "config.php";
$error = "";
$oldLogin = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $oldLogin = trim($_POST["login"] ?? "");
    $password = $_POST["password"] ?? "";
    if ($oldLogin === "" || $password === "") {
        $error = "Please enter your email or contact number and password.";
    } else {
        try {
            $st = $pdo->prepare("SELECT user_id,customer_id,staff_id,full_name,email,password_hash,role,status FROM users WHERE role='Customer' AND status='Active' AND (email=? OR customer_id IN (SELECT customer_id FROM customers WHERE contact_number=?)) LIMIT 1");
            $st->execute([$oldLogin, $oldLogin]);
            $u=$st->fetch();
            if ($u && password_verify($password,$u["password_hash"])) {
                session_regenerate_id(true);
                unset($u["password_hash"]);
                $_SESSION["user"]=$u;
                redirect("customer-dashboard.php");
            }
            $error="Invalid customer login details.";
        } catch(PDOException $e) {
            $error="Login could not be completed. Make sure MySQL is running and the MRA Hotel database is imported.";
        }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MRA Hotel | Customer Login</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="auth">
<div class="auth-panel">
  <div class="auth-inner auth-modern">
    <a class="auth-brand" href="index.php"><img src="assets/mra-logo.png" alt="MRA Hotel"><span>MRA HOTEL</span></a>
    <div class="auth-heading"><span class="eyebrow">CUSTOMER PORTAL</span><h1>Welcome back.</h1><p>Sign in securely to manage your reservations, payments, dining orders, profile, notifications and reviews.</p></div>
    <?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?>
    <form method="post" class="form auth-form" autocomplete="on">
      <label>Email or Contact Number<input type="text" name="login" value="<?=e($oldLogin)?>" placeholder="you@example.com or 09XXXXXXXXX" autocomplete="username" required></label>
      <label>Password<input type="password" name="password" placeholder="Enter your password" autocomplete="current-password" required></label>
      <button class="btn full auth-submit" type="submit">SIGN IN AS CUSTOMER</button>
    </form>
    <div class="auth-links"><a href="signup.php">Create Customer Account</a><span>·</span><a href="admin-login.php">Management Login</a></div>
    <div class="auth-note"><b>Customer access only.</b><br>Management users must use the private Management Login.</div>
    <a class="back-home" href="index.php">← Back to MRA Hotel</a>
  </div>
</div><div class="auth-image"></div>
</body></html>