<?php require "config.php";
$amenities=[
["High-Speed Wi-Fi","Fast complimentary internet in rooms and shared spaces.","📶","Included"],
["Smart TV & Streaming","Smart television for entertainment after a long day.","📺","In-room"],
["Coffee & Tea Station","Complimentary coffee and tea setup in selected rooms.","☕","In-room"],
["Premium Toiletries","Shampoo, body wash, towels, hair dryer, and essentials.","🧴","In-room"],
["Air Conditioning","Individually controlled climate comfort in every guest room.","❄️","In-room"],
["Work Desk","A dedicated workspace for business travelers and remote work.","💻","Selected rooms"],
["Bottled Water","Complimentary bottled water refreshed by housekeeping.","💧","Included"],
["Daily Housekeeping","Room cleaning and replenishment during your stay.","🧹","Hotel service"],
["24/7 Guest Support","Front desk assistance for guest requests and concerns.","🛎️","24/7"]
];
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Amenities | MRA Hotel</title><link rel="stylesheet" href="assets/style.css"></head><body>
<header class="site-header"><a class="brand" href="index.php"><img class="brand-logo" src="assets/mra-logo.png" alt="MRA Hotel"><span>MRA HOTEL</span></a><nav><a href="index.php">Home</a><a href="rooms.php">Rooms</a><a href="amenities.php">Amenities</a><a href="facilities.php">Facilities</a><a href="dining.php">Dining</a><a href="about.php">About Us</a><a href="gallery.php">Gallery</a><a href="reviews.php">Reviews</a><a href="blog.php">Blog</a><a href="location.php">Location</a><a href="contact.php">Contact</a><a href="login.php">Login</a><a href="signup.php">Sign Up</a></nav></header>
<main class="section"><p class="eyebrow">GUEST AMENITIES</p><h1>Comfort in the details.</h1><p class="lead">Amenities are the everyday conveniences inside your room and throughout your stay. For our larger spaces and leisure venues, visit Facilities.</p>
<div class="amenity-grid"><?php foreach($amenities as $a):?><article class="amenity-card"><div class="amenity-icon"><?=$a[2]?></div><div><span class="pill"><?=e($a[3])?></span><h2><?=e($a[0])?></h2><p><?=e($a[1])?></p></div></article><?php endforeach;?></div>
<div class="included-box"><b>Looking for leisure facilities?</b><p>Visit our Swimming Pool, Fitness Gym, Restaurant, Café, Parking, and 24/7 Front Desk on the Facilities page.</p><a class="btn small" href="facilities.php">EXPLORE FACILITIES</a></div></main>
<footer><div><img class="brand-logo" src="assets/mra-logo.png" alt="MRA Hotel"><p>Stay. Relax. Experience MRA.</p></div><div><b>Contact</b><p>MRA Hotel Avenue<br>(02) 8123-4567<br>0917-000-0000<br>reservations@mrahotel.com</p></div><div><b>Social</b><p>Facebook · Instagram · TikTok · Messenger</p></div></footer></body></html>