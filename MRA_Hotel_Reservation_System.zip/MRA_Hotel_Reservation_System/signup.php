<?php
require "config.php";

$error = "";
$first = $last = $email = $contact = $address = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $first   = trim($_POST["first_name"] ?? "");
    $last    = trim($_POST["last_name"] ?? "");
    $email   = trim($_POST["email"] ?? "");
    $contact = trim($_POST["contact"] ?? "");
    $address = trim($_POST["address"] ?? "");
    $pass    = $_POST["password"] ?? "";
    $confirm = $_POST["confirm_password"] ?? "";

    if ($first === "" || $last === "" || $contact === "" || $address === "") {
        $error = "Please complete all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (strlen($pass) < 6) {
        $error = "Password must be at least 6 characters.";
    } elseif ($pass !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        try {
            // Customer ID details are collected during booking, not during account creation.
            $check = $pdo->prepare("SELECT customer_id FROM customers WHERE email = ? LIMIT 1");
            $check->execute([$email]);

            if ($check->fetch()) {
                $error = "That email is already registered. Please use Customer Login.";
            } else {
                $pdo->beginTransaction();

                // These values are placeholders until the customer completes ID verification
                // during the actual hotel booking.
                $s = $pdo->prepare(
                    "INSERT INTO customers
                    (first_name,last_name,contact_number,email,address,id_type,id_number)
                    VALUES (?,?,?,?,?,'Pending','Pending')"
                );
                $s->execute([$first, $last, $contact, $email, $address]);
                $cid = (int)$pdo->lastInsertId();

                $hash = password_hash($pass, PASSWORD_DEFAULT);
                $s = $pdo->prepare(
                    "INSERT INTO users
                    (customer_id,staff_id,full_name,email,password_hash,role,status)
                    VALUES (?,NULL,?,?,?,?, 'Active')"
                );
                $s->execute([$cid, "$first $last", $email, $hash, "Customer"]);
                $uid = (int)$pdo->lastInsertId();

                $pdo->commit();

                session_regenerate_id(true);
                $_SESSION["user"] = [
                    "user_id" => $uid,
                    "customer_id" => $cid,
                    "staff_id" => null,
                    "full_name" => "$first $last",
                    "email" => $email,
                    "role" => "Customer",
                    "status" => "Active"
                ];

                redirect("customer-dashboard.php");
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = "Account creation failed. Please make sure the MRA Hotel database is imported and try again.";
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>MRA Hotel | Customer Sign Up</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="auth-page">
<div class="auth-shell">
    <section class="auth-panel">
        <div class="auth-inner auth-signup-card">
            <a class="auth-brand" href="index.php">
                <img src="assets/mra-logo.png" alt="MRA Hotel Logo">
                <span>MRA HOTEL</span>
            </a>

            <div class="auth-heading">
                <span class="eyebrow">CUSTOMER ACCOUNT</span>
                <h1>Create your account.</h1>
                <p>Join MRA Hotel to reserve rooms, manage bookings, order dining, receive notifications, and leave reviews.</p>
            </div>

            <?php if ($error): ?>
                <div class="alert" role="alert"><?=e($error)?></div>
            <?php endif; ?>

            <form method="post" class="form auth-form signup-form" autocomplete="on" novalidate>
                <div class="two">
                    <label>First Name
                        <input name="first_name" value="<?=e($first)?>" autocomplete="given-name" required>
                    </label>
                    <label>Last Name
                        <input name="last_name" value="<?=e($last)?>" autocomplete="family-name" required>
                    </label>
                </div>

                <label>Email Address
                    <input type="email" name="email" value="<?=e($email)?>" autocomplete="email" inputmode="email" placeholder="you@example.com" required>
                </label>

                <label>Contact Number
                    <input type="tel" name="contact" value="<?=e($contact)?>" autocomplete="tel" inputmode="tel" placeholder="09XXXXXXXXX" required>
                </label>

                <label>Address
                    <input name="address" value="<?=e($address)?>" autocomplete="street-address" placeholder="Complete address" required>
                </label>

                <div class="two">
                    <label>Password
                        <input id="signupPassword" type="password" name="password" minlength="6" autocomplete="new-password" required>
                    </label>
                    <label>Confirm Password
                        <input id="signupConfirm" type="password" name="confirm_password" minlength="6" autocomplete="new-password" required>
                    </label>
                </div>

                <p class="auth-helper">At least 6 characters. Your password is securely hashed and never displayed publicly.</p>

                <button type="submit" class="btn full auth-submit">CREATE CUSTOMER ACCOUNT</button>
            </form>

            <div class="auth-links">
                <span>Already have an account?</span>
                <a href="login.php">Customer Login</a>
            </div>

            <div class="auth-secondary">
                <a href="signup-choice.php">← Choose another account type</a>
                <a href="index.php">Back to MRA Hotel</a>
            </div>
        </div>
    </section>

    <aside class="auth-image auth-image-signup" aria-label="MRA Hotel">
        <div class="auth-image-caption">
            <span class="eyebrow">STAY · RELAX · EXPERIENCE</span>
            <h2>Your MRA Hotel journey starts here.</h2>
            <p>Create your customer account and make your next stay simple.</p>
        </div>
    </aside>
</div>
</body>
</html>
