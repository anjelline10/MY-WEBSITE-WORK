# MRA Hotel Database — 3NF Documentation

## 1NF — Atomic values / no repeating groups
Each field contains one value only. For example, Customer has separate FirstName and LastName fields, while Reservation stores one check-in date, one check-out date, and numeric guest counts. Room amenities are descriptive text rather than multiple numbered columns.

## 2NF — Remove partial dependency
Every table has a single-column primary key, so non-key attributes depend on the whole key. Room information that depends on RoomTypeID is separated into ROOM_TYPE instead of being repeated for every room.

Example:
- ROOM(RoomID, RoomNumber, RoomTypeID, FloorNumber, Status)
- ROOM_TYPE(RoomTypeID, TypeName, Capacity, PricePerNight, Size, BedType, Description, Amenities)

## 3NF — Remove transitive dependency
Non-key attributes do not depend on another non-key attribute. RoomTypeName, Capacity and PricePerNight depend on RoomTypeID, not RoomID. Payment details depend on PaymentID/ReservationID, while customer details depend on CustomerID.

Final main tables:
CUSTOMER
ROOM_TYPE
ROOM
RESERVATION
PAYMENT
STAFF

Supporting authentication table:
USERS
