-- MRA HOTEL - SINGLE DATABASE IMPORT FILE
-- Import this ONE file in phpMyAdmin. It creates the complete school-project database.
CREATE DATABASE IF NOT EXISTS mra_hotel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mra_hotel;

-- Clean reinstall: safe for a fresh school-project database.
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS blogs;
DROP TABLE IF EXISTS facilities;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS rooms;
DROP TABLE IF EXISTS room_types;
DROP TABLE IF EXISTS staff;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS customers;
SET FOREIGN_KEY_CHECKS=1;

-- 1. CUSTOMER
CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    contact_number VARCHAR(30) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    address VARCHAR(255) NOT NULL,
    id_type VARCHAR(50) NOT NULL,
    id_number VARCHAR(80) NOT NULL,
    id_image VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. STAFF / MANAGEMENT
CREATE TABLE staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    position ENUM('Staff','Manager','Admin','Owner') NOT NULL,
    contact_number VARCHAR(30),
    username VARCHAR(80) UNIQUE,
    password_hash VARCHAR(255),
    account_status ENUM('Active','Inactive') DEFAULT 'Active'
) ENGINE=InnoDB;

-- 3. ROOM TYPE
CREATE TABLE room_types (
    room_type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(50) NOT NULL UNIQUE,
    capacity INT NOT NULL,
    price_per_night DECIMAL(10,2) NOT NULL,
    size_sqm DECIMAL(6,2) NOT NULL,
    bed_type VARCHAR(80) NOT NULL,
    description TEXT,
    amenities TEXT,
    image_url VARCHAR(500)
) ENGINE=InnoDB;

-- 4. ROOM
CREATE TABLE rooms (
    room_id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) NOT NULL UNIQUE,
    room_type_id INT NOT NULL,
    floor_number INT NOT NULL,
    status ENUM('Available','Occupied','Reserved','Cleaning','Maintenance') DEFAULT 'Available',
    CONSTRAINT fk_rooms_room_type
        FOREIGN KEY (room_type_id) REFERENCES room_types(room_type_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 5. RESERVATION
CREATE TABLE reservations (
    reservation_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    room_id INT NOT NULL,
    staff_id INT NULL,
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    check_in_time TIME NULL,
    check_out_time TIME NULL,
    number_of_adults INT NOT NULL,
    number_of_children INT NOT NULL DEFAULT 0,
    total_guests INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    reservation_status ENUM('Pending','Confirmed','Checked-in','Checked-out','Cancelled') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_res_customer
        FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_res_room
        FOREIGN KEY (room_id) REFERENCES rooms(room_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_res_staff
        FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- 6. PAYMENT
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT NOT NULL,
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    payment_method ENUM('Cash','GCash','Card','Bank Transfer','QR Payment') NOT NULL,
    amount_paid DECIMAL(10,2) NOT NULL DEFAULT 0,
    payment_status ENUM('Pending','Partial','Paid','Refunded') DEFAULT 'Pending',
    reference_number VARCHAR(100),
    CONSTRAINT fk_payment_reservation
        FOREIGN KEY (reservation_id) REFERENCES reservations(reservation_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 7. USER LOGIN ACCOUNTS
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NULL,
    staff_id INT NULL,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('Customer','Staff','Manager','Admin','Owner') NOT NULL,
    status ENUM('Active','Inactive') DEFAULT 'Active',
    CONSTRAINT fk_users_customer
        FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_users_staff
        FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- 8. REVIEWS
CREATE TABLE reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    reservation_id INT NULL,
    rating TINYINT NOT NULL,
    review_text TEXT,
    review_status ENUM('Pending','Approved','Hidden') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_rating CHECK (rating BETWEEN 1 AND 5),
    CONSTRAINT fk_review_customer
        FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_review_reservation
        FOREIGN KEY (reservation_id) REFERENCES reservations(reservation_id)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- ROOM TYPES: 6 types, total capacity = 620 guests
INSERT INTO room_types (room_type_id,type_name,capacity,price_per_night,size_sqm,bed_type,description,amenities,image_url) VALUES
(1,'Standard Room',2,2200.00,26.00,'1 Queen Bed','Comfortable and practical for short stays.','Wi-Fi, AC, Smart TV, Private Bathroom, Toiletries','https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=85'),
(2,'Deluxe Room',2,2800.00,32.00,'1 King Bed','A polished room with extra space and a calm boutique feel.','Wi-Fi, AC, Smart TV, Refrigerator, Coffee Station, Work Desk','https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=1200&q=85'),
(3,'Twin Room',2,2600.00,30.00,'2 Single Beds','Flexible sleeping arrangement for friends or colleagues.','Wi-Fi, AC, Smart TV, Private Bathroom, Work Desk','https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=85'),
(4,'Family Room',4,3800.00,42.00,'2 Queen Beds','Spacious accommodation for families and small groups.','Wi-Fi, AC, Smart TV, Refrigerator, Sofa, Toiletries','https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=1200&q=85'),
(5,'Executive Room',3,4500.00,48.00,'1 King Bed + Sofa Bed','Premium room for business and leisure travelers.','Wi-Fi, AC, Smart TV, Mini Fridge, Work Desk, Lounge Area','https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=85'),
(6,'Suite',6,6500.00,68.00,'1 King Bed + 2 Sofa Beds','Our largest room type, designed for extended and group stays.','Wi-Fi, AC, Smart TV, Living Area, Dining Area, Bathtub','https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=1200&q=85');

-- FULL 210-ROOM INVENTORY
-- Standard 50, Deluxe 45, Twin 35, Family 30, Executive 20, Suite 30.
INSERT INTO rooms (room_number, room_type_id, floor_number, status) VALUES
('S01',1,1,'Available'),
('S02',1,1,'Available'),
('S03',1,1,'Available'),
('S04',1,1,'Available'),
('S05',1,1,'Available'),
('S06',1,1,'Available'),
('S07',1,1,'Available'),
('S08',1,1,'Available'),
('S09',1,1,'Available'),
('S10',1,1,'Available'),
('S11',1,2,'Available'),
('S12',1,2,'Available'),
('S13',1,2,'Available'),
('S14',1,2,'Available'),
('S15',1,2,'Available'),
('S16',1,2,'Available'),
('S17',1,2,'Available'),
('S18',1,2,'Available'),
('S19',1,2,'Available'),
('S20',1,2,'Available'),
('S21',1,3,'Available'),
('S22',1,3,'Available'),
('S23',1,3,'Available'),
('S24',1,3,'Available'),
('S25',1,3,'Available'),
('S26',1,3,'Available'),
('S27',1,3,'Available'),
('S28',1,3,'Available'),
('S29',1,3,'Available'),
('S30',1,3,'Available'),
('S31',1,4,'Available'),
('S32',1,4,'Available'),
('S33',1,4,'Available'),
('S34',1,4,'Available'),
('S35',1,4,'Available'),
('S36',1,4,'Available'),
('S37',1,4,'Available'),
('S38',1,4,'Available'),
('S39',1,4,'Available'),
('S40',1,4,'Available'),
('S41',1,5,'Available'),
('S42',1,5,'Available'),
('S43',1,5,'Available'),
('S44',1,5,'Available'),
('S45',1,5,'Available'),
('S46',1,5,'Available'),
('S47',1,5,'Available'),
('S48',1,5,'Available'),
('S49',1,5,'Available'),
('S50',1,5,'Available'),
('D01',2,1,'Available'),
('D02',2,1,'Available'),
('D03',2,1,'Available'),
('D04',2,1,'Available'),
('D05',2,1,'Available'),
('D06',2,1,'Available'),
('D07',2,1,'Available'),
('D08',2,1,'Available'),
('D09',2,1,'Available'),
('D10',2,1,'Available'),
('D11',2,2,'Available'),
('D12',2,2,'Available'),
('D13',2,2,'Available'),
('D14',2,2,'Available'),
('D15',2,2,'Available'),
('D16',2,2,'Available'),
('D17',2,2,'Available'),
('D18',2,2,'Available'),
('D19',2,2,'Available'),
('D20',2,2,'Available'),
('D21',2,3,'Available'),
('D22',2,3,'Available'),
('D23',2,3,'Available'),
('D24',2,3,'Available'),
('D25',2,3,'Available'),
('D26',2,3,'Available'),
('D27',2,3,'Available'),
('D28',2,3,'Available'),
('D29',2,3,'Available'),
('D30',2,3,'Available'),
('D31',2,4,'Available'),
('D32',2,4,'Available'),
('D33',2,4,'Available'),
('D34',2,4,'Available'),
('D35',2,4,'Available'),
('D36',2,4,'Available'),
('D37',2,4,'Available'),
('D38',2,4,'Available'),
('D39',2,4,'Available'),
('D40',2,4,'Available'),
('D41',2,5,'Available'),
('D42',2,5,'Available'),
('D43',2,5,'Available'),
('D44',2,5,'Available'),
('D45',2,5,'Available'),
('T01',3,1,'Available'),
('T02',3,1,'Available'),
('T03',3,1,'Available'),
('T04',3,1,'Available'),
('T05',3,1,'Available'),
('T06',3,1,'Available'),
('T07',3,1,'Available'),
('T08',3,1,'Available'),
('T09',3,1,'Available'),
('T10',3,1,'Available'),
('T11',3,2,'Available'),
('T12',3,2,'Available'),
('T13',3,2,'Available'),
('T14',3,2,'Available'),
('T15',3,2,'Available'),
('T16',3,2,'Available'),
('T17',3,2,'Available'),
('T18',3,2,'Available'),
('T19',3,2,'Available'),
('T20',3,2,'Available'),
('T21',3,3,'Available'),
('T22',3,3,'Available'),
('T23',3,3,'Available'),
('T24',3,3,'Available'),
('T25',3,3,'Available'),
('T26',3,3,'Available'),
('T27',3,3,'Available'),
('T28',3,3,'Available'),
('T29',3,3,'Available'),
('T30',3,3,'Available'),
('T31',3,4,'Available'),
('T32',3,4,'Available'),
('T33',3,4,'Available'),
('T34',3,4,'Available'),
('T35',3,4,'Available'),
('F01',4,1,'Available'),
('F02',4,1,'Available'),
('F03',4,1,'Available'),
('F04',4,1,'Available'),
('F05',4,1,'Available'),
('F06',4,1,'Available'),
('F07',4,1,'Available'),
('F08',4,1,'Available'),
('F09',4,1,'Available'),
('F10',4,1,'Available'),
('F11',4,2,'Available'),
('F12',4,2,'Available'),
('F13',4,2,'Available'),
('F14',4,2,'Available'),
('F15',4,2,'Available'),
('F16',4,2,'Available'),
('F17',4,2,'Available'),
('F18',4,2,'Available'),
('F19',4,2,'Available'),
('F20',4,2,'Available'),
('F21',4,3,'Available'),
('F22',4,3,'Available'),
('F23',4,3,'Available'),
('F24',4,3,'Available'),
('F25',4,3,'Available'),
('F26',4,3,'Available'),
('F27',4,3,'Available'),
('F28',4,3,'Available'),
('F29',4,3,'Available'),
('F30',4,3,'Available'),
('E01',5,1,'Available'),
('E02',5,1,'Available'),
('E03',5,1,'Available'),
('E04',5,1,'Available'),
('E05',5,1,'Available'),
('E06',5,1,'Available'),
('E07',5,1,'Available'),
('E08',5,1,'Available'),
('E09',5,1,'Available'),
('E10',5,1,'Available'),
('E11',5,2,'Available'),
('E12',5,2,'Available'),
('E13',5,2,'Available'),
('E14',5,2,'Available'),
('E15',5,2,'Available'),
('E16',5,2,'Available'),
('E17',5,2,'Available'),
('E18',5,2,'Available'),
('E19',5,2,'Available'),
('E20',5,2,'Available'),
('SU01',6,1,'Available'),
('SU02',6,1,'Available'),
('SU03',6,1,'Available'),
('SU04',6,1,'Available'),
('SU05',6,1,'Available'),
('SU06',6,1,'Available'),
('SU07',6,1,'Available'),
('SU08',6,1,'Available'),
('SU09',6,1,'Available'),
('SU10',6,1,'Available'),
('SU11',6,2,'Available'),
('SU12',6,2,'Available'),
('SU13',6,2,'Available'),
('SU14',6,2,'Available'),
('SU15',6,2,'Available'),
('SU16',6,2,'Available'),
('SU17',6,2,'Available'),
('SU18',6,2,'Available'),
('SU19',6,2,'Available'),
('SU20',6,2,'Available'),
('SU21',6,3,'Available'),
('SU22',6,3,'Available'),
('SU23',6,3,'Available'),
('SU24',6,3,'Available'),
('SU25',6,3,'Available'),
('SU26',6,3,'Available'),
('SU27',6,3,'Available'),
('SU28',6,3,'Available'),
('SU29',6,3,'Available'),
('SU30',6,3,'Available');

CREATE TABLE notifications (
 notification_id INT AUTO_INCREMENT PRIMARY KEY,
 customer_id INT NULL,
 title VARCHAR(150) NOT NULL,
 message TEXT NOT NULL,
 is_read TINYINT(1) DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE blogs (
 blog_id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(180) NOT NULL,
 author VARCHAR(100) NOT NULL,
 image_url VARCHAR(500),
 content TEXT NOT NULL,
 published_at DATE NOT NULL,
 status ENUM('Published','Draft') DEFAULT 'Published'
) ENGINE=InnoDB;

CREATE TABLE facilities (
 facility_id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 description TEXT,
 operating_hours VARCHAR(100),
 guest_access VARCHAR(100),
 image_url VARCHAR(500),
 status ENUM('Active','Inactive') DEFAULT 'Active'
) ENGINE=InnoDB;

INSERT INTO facilities(name,description,operating_hours,guest_access,image_url) VALUES
('Swimming Pool','Free pool access for registered hotel guests.','6:00 AM - 10:00 PM','Registered guests','https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=1000&q=85'),
('Fitness Gym','Modern equipment for guest workouts.','6:00 AM - 10:00 PM','Registered guests','https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1400&q=90'),
('Restaurant','All-day dining and breakfast.','6:00 AM - 10:00 PM','Guests and visitors','https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=1000&q=85'),
('Cafe','Coffee, pastries, and light snacks.','7:00 AM - 9:00 PM','Guests and visitors','https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1000&q=85'),
('Parking','Convenient guest parking.','24 hours','Registered guests','https://images.unsplash.com/photo-1506521781263-d8422e82f27a?auto=format&fit=crop&w=1000&q=85'),
('24/7 Front Desk','Guest assistance and hotel support.','24 hours','All guests','https://images.unsplash.com/photo-1564501049412-61c2a3083791?auto=format&fit=crop&w=1000&q=85');

INSERT INTO blogs(title,author,image_url,content,published_at) VALUES
('5 Tips for a Comfortable Hotel Stay','MRA Hotel','https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=1000&q=85','Plan your check-in, keep your ID ready, use hotel amenities, and tell our team how we can help.','2026-08-01'),
('Best Things to Do Near MRA Hotel','MRA Hotel','https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1000&q=85','Discover nearby dining, leisure, shopping, and transportation options.','2026-08-03'),
('Why Choose MRA Hotel?','MRA Hotel','https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1000&q=85','Comfortable rooms, thoughtful service, pool and gym access, and easy digital booking.','2026-08-05');

-- STAFF / ADMIN / MANAGER / OWNER SCHOOL DEMO ACCOUNTS
-- Admin / Manager / Staff password: 12345
-- Owner password: 2468
INSERT INTO staff
(first_name,last_name,position,contact_number,username,password_hash,account_status)
VALUES
('MRA','Admin','Admin','09170000001','admin','$2y$12$0X1HN4DFWsxRdNGHoFEvN.c8P3O70WhC.prQmLthkE3Ps2PjnpFPe','Active'),
('MRA','Manager','Manager','09170000002','manager','$2y$12$0X1HN4DFWsxRdNGHoFEvN.c8P3O70WhC.prQmLthkE3Ps2PjnpFPe','Active'),
('MRA','Staff','Staff','09170000003','staff','$2y$12$0X1HN4DFWsxRdNGHoFEvN.c8P3O70WhC.prQmLthkE3Ps2PjnpFPe','Active'),
('MRA','Owner','Owner','09170000004','owner','$2y$12$NysXZZ4TGFTARWKWp8Q8Te/c4umqRahM5n5inTVUz68xrA8HNgfIK','Active');
INSERT INTO users
(staff_id,full_name,email,password_hash,role,status)
VALUES
(1,'MRA Admin','admin@mrahotel.com','$2y$12$0X1HN4DFWsxRdNGHoFEvN.c8P3O70WhC.prQmLthkE3Ps2PjnpFPe','Admin','Active'),
(2,'MRA Manager','manager@mrahotel.com','$2y$12$0X1HN4DFWsxRdNGHoFEvN.c8P3O70WhC.prQmLthkE3Ps2PjnpFPe','Manager','Active'),
(3,'MRA Staff','staff@mrahotel.com','$2y$12$0X1HN4DFWsxRdNGHoFEvN.c8P3O70WhC.prQmLthkE3Ps2PjnpFPe','Staff','Active'),
(4,'MRA Owner','owner@mrahotel.com','$2y$12$NysXZZ4TGFTARWKWp8Q8Te/c4umqRahM5n5inTVUz68xrA8HNgfIK','Owner','Active');

-- OPTIONAL SAMPLE CUSTOMER (for READ/CRUD demonstration)
INSERT INTO customers
(first_name,last_name,contact_number,email,address,id_type,id_number)
VALUES
('Juan','Dela Cruz','09123456789','juan.demo@mrahotel.com','Manila','National ID','DEMO-123456');
INSERT INTO users
(customer_id,full_name,email,password_hash,role,status)
VALUES
(1,'Juan Dela Cruz','juan.demo@mrahotel.com','$2y$12$0X1HN4DFWsxRdNGHoFEvN.c8P3O70WhC.prQmLthkE3Ps2PjnpFPe','Customer','Active');

-- SAMPLE APPROVED REVIEWS FOR THE PUBLIC REVIEWS PAGE
INSERT INTO reviews(customer_id,reservation_id,rating,review_text,review_status) VALUES
(1,NULL,5,'The room was spotless, the staff were warm, and the breakfast was excellent.','Approved'),
(1,NULL,5,'Beautiful hotel atmosphere. The pool and gym made our weekend stay feel complete.','Approved'),
(1,NULL,4,'The room was spacious and comfortable. Dining choices were convenient and reasonably priced.','Approved'),
(1,NULL,5,'Easy reservation process and a very relaxing stay. I would gladly return to MRA Hotel.','Approved'),
(1,NULL,4,'Professional service, comfortable beds, and a lovely restaurant experience.','Approved');

-- FIVE SQL CRUD EXAMPLES FOR THE PRESENTATION
-- CREATE
-- INSERT INTO customers(first_name,last_name,contact_number,email,address,id_type,id_number)
-- VALUES ('Maria','Santos','09123456789','maria@example.com','Manila','National ID','123456');
-- READ
-- SELECT * FROM reservations WHERE customer_id = 1;
-- UPDATE
-- UPDATE rooms SET status = 'Maintenance' WHERE room_id = 1;
-- DELETE
-- DELETE FROM customers WHERE customer_id = 10;
-- READ WITH JOIN
-- SELECT r.reservation_id, CONCAT(c.first_name,' ',c.last_name) AS customer,
--        rm.room_number, rt.type_name, r.check_in_date, r.check_out_date,
--        r.total_amount, r.reservation_status
-- FROM reservations r
-- JOIN customers c ON c.customer_id=r.customer_id
-- JOIN rooms rm ON rm.room_id=r.room_id
-- JOIN room_types rt ON rt.room_type_id=rm.room_type_id
-- ORDER BY r.reservation_id DESC;

-- QUICK CHECKS
-- SELECT COUNT(*) AS total_rooms FROM rooms;       -- expected 210
-- SELECT SUM(rt.capacity) AS total_capacity FROM rooms rm JOIN room_types rt ON rt.room_type_id=rm.room_type_id; -- expected 620
-- SELECT * FROM room_types;
-- SELECT * FROM users;

COMMIT;