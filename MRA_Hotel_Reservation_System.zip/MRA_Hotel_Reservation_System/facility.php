<?php
require "config.php";
$id=(int)($_GET["id"]??0);
$st=$pdo->prepare("SELECT * FROM facilities WHERE facility_id=? AND status='Active'");
$st->execute([$id]);
$f=$st->fetch();
if(!$f){http_response_code(404); exit("Facility not found.");}
$gallery=[
  1=>[
    "https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=1400&q=90",
    "https://images.unsplash.com/photo-1572331165267-854da2b10ccc?auto=format&fit=crop&w=1200&q=90",
    "https://images.unsplash.com/photo-1600965962361-9035dbfd1c50?auto=format&fit=crop&w=1200&q=90"
  ],
  2=>[
    "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1400&q=90",
    "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1a?auto=format&fit=crop&w=1200&q=90",
    "https://images.unsplash.com/photo-1599058917212-d750089bc07e?auto=format&fit=crop&w=1200&q=90"
  ],
  3=>[
    "https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=1400&q=90",
    "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=90",
    "https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=1200&q=90"
  ],
  4=>[
    "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1400&q=90",
    "https://images.unsplash.com/photo-1445116572660-236099ec97a0?auto=format&fit=crop&w=1200&q=90",
    "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1200&q=90"
  ],
  5=>[
    "https://images.unsplash.com/photo-1506521781263-d8422e82f27a?auto=format&fit=crop&w=1400&q=90",
    "https://images.unsplash.com/photo-1590674899484-d5640e854abe?auto=format&fit=crop&w=1200&q=90",
    "https://images.unsplash.com/photo-1545179605-1296651e9d43?auto=format&fit=crop&w=1200&q=90"
  ],
  6=>[
    "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1400&q=90",
    "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=90",
    "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=1200&q=90"
  ]
];
$imgs=$gallery[$id]??[$f["image_url"]];
$extra=[
  1=>["Pool deck","Sun loungers","Family-friendly swimming area","Towels available","Guest pool access"],
  2=>["Cardio machines","Strength equipment","Free weights","Air-conditioned workout area","Guest gym access"],
  3=>["Breakfast dining","Lunch and dinner","Indoor seating","À la carte menu","Room-service friendly"],
  4=>["Coffee bar","Pastries","Light snacks","Comfortable seating","Takeaway available"],
  5=>["Guest parking","Accessible spaces","Well-lit area","Hotel guest priority","24-hour access"],
  6=>["Reception desk","Concierge support","Check-in assistance","Guest requests","24-hour service"]
];
$list=$extra[$id]??["Guest access","Hotel service","Comfortable environment"];
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($f["name"])?> | MRA Hotel</title><link rel="stylesheet" href="assets/style.css"></head><body>
<header class="site-header"><a class="brand" href="index.php"><img class="brand-logo" src="assets/mra-logo.png" alt="MRA Hotel Logo"><span>MRA HOTEL</span></a>
<nav><a href="index.php">Home</a><a href="rooms.php">Rooms</a><a href="amenities.php">Amenities</a><a href="facilities.php">Facilities</a><a href="dining.php">Dining</a><a href="about.php">About Us</a><a href="gallery.php">Gallery</a><a href="reviews.php">Reviews</a><a href="blog.php">Blog</a><a href="location.php">Location</a><a href="contact.php">Contact</a><a href="login.php">Login</a><a href="signup.php">Sign Up</a></nav></header>
<main class="facility-detail"><div class="facility-main"><div class="facility-detail-slider"><img id="facilityMainImage" src="<?=e($imgs[0])?>" alt="<?=e($f["name"])?>"></div><div class="facility-gallery"><?php foreach($imgs as $im):?><img src="<?=e($im)?>" alt="<?=e($f["name"])?>" data-main-image="<?=e($im)?>" onclick="document.getElementById('facilityMainImage').src=this.dataset.mainImage"><?php endforeach;?></div></div>
<div><p class="eyebrow">MRA HOTEL EXPERIENCE</p><h1><?=e($f["name"])?></h1><p class="lead"><?=e($f["description"])?></p>
<div class="detail-grid"><div><b>Operating Hours</b><span><?=e($f["operating_hours"])?></span></div><div><b>Guest Access</b><span><?=e($f["guest_access"])?></span></div></div>
<h2>What you'll find</h2><div class="feature-list"><?php foreach($list as $item):?><div>✓ <?=e($item)?></div><?php endforeach;?></div>
<div class="included"><b>Guest Note</b><p class="muted">Facility availability may be subject to hotel rules, maintenance schedules, and safe-use limits. Please follow posted guidelines and staff instructions.</p></div>
<a class="btn" href="facilities.php">← Back to Facilities</a></div></main>
<footer><div><b>MRA HOTEL</b><p>Stay. Relax. Experience MRA.</p></div><div><b>Contact</b><p>MRA Hotel Avenue<br>(02) 8123-4567<br>0917-000-0000<br>reservations@mrahotel.com</p></div><div><b>Social</b><p>Facebook · Instagram · TikTok · Messenger</p></div></footer>
<script>
const facilityDetailImages=<?=json_encode($imgs)?>;let facilityDetailIndex=0;
const facilityMainImage=document.getElementById('facilityMainImage');
if(facilityMainImage&&facilityDetailImages.length>1){setInterval(()=>{facilityDetailIndex=(facilityDetailIndex+1)%facilityDetailImages.length;facilityMainImage.style.opacity='0';setTimeout(()=>{facilityMainImage.src=facilityDetailImages[facilityDetailIndex];facilityMainImage.style.opacity='1';},180);},3000);}
</script></body></html>