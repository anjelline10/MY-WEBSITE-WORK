<?php
require "config.php";
require_login(["Customer"]);
$u=$_SESSION["user"];
$type=(int)($_GET["type"]??$_POST["room_type_id"]??0);
$error=""; $rt=null;
$t=$pdo->prepare("SELECT * FROM room_types WHERE room_type_id=?"); $t->execute([$type]); $rt=$t->fetch();
if(!$rt) exit("Room type not found.");

if($_SERVER["REQUEST_METHOD"]==="POST"){
    $in=$_POST["check_in"]??""; $out=$_POST["check_out"]??"";
    $ad=(int)($_POST["adults"]??0); $ch=(int)($_POST["children"]??0); $guests=$ad+$ch;
    $pay=$_POST["payment_method"]??"Cash";
    $idType=trim($_POST["id_type"]??""); $idNum=trim($_POST["id_number"]??"");
    $rules=$_POST["agree_rules"]??"";
    $checkInTime=trim($_POST["check_in_time"]??"");
    $checkOutTime=trim($_POST["check_out_time"]??"");
    $startTs=($in&&$checkInTime)?strtotime("$in $checkInTime"):0;
    $endTs=($out&&$checkOutTime)?strtotime("$out $checkOutTime"):0;
    $hours=($startTs&&$endTs)?(($endTs-$startTs)/3600):0;
    $nights=$hours>0?max(1,(int)ceil($hours/24)):0;

    if(!$in||!$out||!$checkInTime||!$checkOutTime||$hours<=0) $error="Please select valid check-in and check-out dates. Check-out must be after check-in.";
    elseif($guests<1||$guests>$rt["capacity"]) $error="The selected room can accommodate up to ".$rt["capacity"]." guests.";
    elseif($idType===""||$idNum==="") $error="Please provide your ID type and ID number.";
    elseif(empty($_FILES["id_image"]["tmp_name"])) $error="A clear valid ID photo is required.";
    elseif($rules!=="yes") $error="Please agree to the MRA Hotel Booking Rules & Policies.";
    else {
        $q=$pdo->prepare("SELECT rm.room_id,rm.room_number FROM rooms rm WHERE rm.room_type_id=? AND rm.status NOT IN('Maintenance','Cleaning') AND NOT EXISTS(
            SELECT 1 FROM reservations x WHERE x.room_id=rm.room_id
            AND x.reservation_status NOT IN('Cancelled','Checked-out')
            AND x.check_in_date < ? AND x.check_out_date > ?
        ) ORDER BY rm.room_number LIMIT 1");
        $q->execute([$type,$out,$in]); $room=$q->fetch();
        if(!$room) $error="No room of this type is available for the selected dates.";
        else {
            try {
                $ext=strtolower(pathinfo($_FILES["id_image"]["name"],PATHINFO_EXTENSION));
                if(!in_array($ext,["jpg","jpeg","png","webp"],true)) throw new Exception("ID must be JPG, PNG, or WEBP.");
                if($_FILES["id_image"]["size"]>8*1024*1024) throw new Exception("ID image must be 8 MB or smaller.");
                $filename="id_".$u["customer_id"]."_".bin2hex(random_bytes(8)).".".$ext;
                $uploadDir=__DIR__."/uploads/";
                if(!is_dir($uploadDir)) mkdir($uploadDir,0750,true);
                $target=$uploadDir.$filename;
                if(!move_uploaded_file($_FILES["id_image"]["tmp_name"],$target)) throw new Exception("ID upload failed.");
                $pdo->beginTransaction();
                $pdo->prepare("UPDATE customers SET id_type=?,id_number=?,id_image=? WHERE customer_id=?")
                    ->execute([$idType,$idNum,"uploads/".$filename,$u["customer_id"]]);
                $total=$nights*(float)$rt["price_per_night"];
                $s=$pdo->prepare("INSERT INTO reservations(customer_id,room_id,staff_id,check_in_date,check_out_date,check_in_time,check_out_time,number_of_adults,number_of_children,total_guests,total_amount,reservation_status)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,'Confirmed')");
                $s->execute([$u["customer_id"],$room["room_id"],null,$in,$out,$checkInTime,$checkOutTime,$ad,$ch,$guests,$total]);
                $rid=$pdo->lastInsertId();
                $s=$pdo->prepare("INSERT INTO payments(reservation_id,payment_method,amount_paid,payment_status) VALUES(?,?,0,'Pending')");
                $s->execute([$rid,$pay]);
                $pdo->prepare("INSERT INTO notifications(customer_id,title,message) VALUES(?,?,?)")
                    ->execute([$u["customer_id"],"Booking Confirmation","Reservation #$rid is confirmed. Check-in: $in. Check-out: $out."]);
                $pdo->commit();

                // Optional email notification. XAMPP must be configured with a mail/SMTP service for delivery.
                $subject="MRA Hotel Reservation #$rid";
                $message="Your MRA Hotel reservation #$rid is confirmed. Check-in: $in. Check-out: $out. Room: ".$room["room_number"].".";
                $headers="From: reservations@mrahotel.com\r\nReply-To: reservations@mrahotel.com";
                @mail($u["email"],$subject,$message,$headers);

                redirect("confirmation.php?id=".$rid);
            } catch(Throwable $e) {
                if($pdo->inTransaction()) $pdo->rollBack();
                $error=$e->getMessage();
            }
        }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Book Your Stay | MRA Hotel</title><link rel="stylesheet" href="assets/style.css"></head>
<body><header class="site-header"><a class="brand" href="index.php"><img class="brand-logo" src="assets/mra-logo.png" alt="MRA Hotel Logo"><span>MRA HOTEL</span></a><nav><a href="index.php">Home</a><a href="rooms.php">Rooms</a><a href="dashboard.php">Dashboard</a><a href="logout.php">Logout</a></nav></header>
<main class="form-page"><p class="eyebrow">RESERVATION</p><h1>Book your stay.</h1>
<?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?>
<form method="post" enctype="multipart/form-data" class="booking-form form" autocomplete="on">
<label>Room Type<select name="room_type_id"><?php foreach($pdo->query("SELECT * FROM room_types ORDER BY room_type_id")->fetchAll() as $x):?><option value="<?=$x["room_type_id"]?>" <?=$x["room_type_id"]==$type?"selected":""?>><?=e($x["type_name"])?> — <?=money($x["price_per_night"])?>/night — up to <?=$x["capacity"]?> guests</option><?php endforeach;?></select></label>
<div class="two"><label>Check-in Date<input type="date" id="in" name="check_in" required></label><label>Check-out Date<input type="date" id="out" name="check_out" required></label></div>
<div class="two">
<label>Check-in Time<input type="time" id="inTime" name="check_in_time" required></label>
<label>Check-out Time<input type="time" id="outTime" name="check_out_time" required></label>
</div>
<div class="card flexible-stay"><b>Choose your own arrival and departure time.</b><p class="muted">There is no fixed hotel time in this system. You select the exact date and time. The system calculates the stay duration automatically and bills each required 24-hour stay block.</p></div>
<div class="two"><label>Adults<input type="number" id="adults" name="adults" min="1" value="1" required></label><label>Children<input type="number" id="children" name="children" min="0" value="0"></label></div>
<div class="card"><b>Room capacity: <?=$rt["capacity"]?> guests</b><p id="guestTotal" class="muted"></p><p id="duration" class="stay-duration">Select your dates to calculate your stay.</p><h3 id="estimate">Estimated total will appear here.</h3></div>

<h2>ID Verification</h2>
<p class="muted">A valid ID is required to complete a hotel reservation. You may take a photo using your device camera or upload an existing image. The ID is stored privately for authorized hotel personnel.</p>
<div class="card id-box">
<div class="two"><label>ID Type<select name="id_type" required><option value="">Select ID Type</option><option>National ID</option><option>Passport</option><option>Driver's License</option><option>Other Government ID</option></select></label><label>ID Number<input name="id_number" required></label></div>
<label>ID Photo<input type="file" id="id_image" name="id_image" accept="image/jpeg,image/png,image/webp" capture="environment" required></label>
<div class="actions"><button type="button" class="btn outline" id="openCam">📷 OPEN CAMERA</button><label class="btn" for="id_image">📁 UPLOAD ID</label></div>
<video id="video" autoplay playsinline style="display:none;width:100%;max-height:320px;background:#222;border-radius:8px"></video>
<canvas id="canvas" style="display:none"></canvas><img id="preview" alt="ID preview" style="display:none;width:100%;max-height:320px;object-fit:contain;border-radius:8px;margin-top:12px">
<p class="muted small-note">Accepted: JPG, PNG, WEBP · Maximum 8 MB. Your ID will not be shown publicly.</p>
</div>

<h2>Booking Rules & Policies</h2>
<div class="policy-box">
<ol>
<li><b>Flexible arrival/departure:</b> Select your preferred check-in and check-out times. The hotel may confirm or adjust the requested time based on room readiness and availability.</li>
<li>A valid government-issued ID is required and the reservation name must match the presented ID.</li>
<li>Guests may not exceed the selected room's maximum capacity.</li>
<li>Cancellation and refund eligibility depend on the hotel's cancellation policy and payment status.</li>
<li>Accepted payment methods are Cash, GCash, Card, Bank Transfer, and QR Payment.</li>
<li>Rooms cannot be double-booked for overlapping dates. The system checks availability before confirmation.</li>
<li>Pool and gym access is subject to operating hours, safety rules, and hotel capacity limits.</li>
<li>Smoking is not allowed in designated non-smoking areas. Guests may be charged for damage or excessive cleaning.</li>
<li>Children must be accompanied by a responsible adult. Extra guest charges may apply when applicable.</li>
<li>Pets are subject to hotel policy and may only be allowed in designated areas.</li>
<li>Guests are expected to respect hotel staff, other guests, and hotel property.</li>
<li>Customer information and uploaded identification are confidential and accessible only to authorized personnel.</li>
</ol>
<label class="agree"><input type="checkbox" name="agree_rules" value="yes" id="agreeRules" required> I have read and agree to the MRA Hotel Booking Rules & Policies.</label>
</div>

<h2>Payment</h2>
<label>Payment Method<select id="paymentMethod" name="payment_method"><option>Cash</option><option>GCash</option><option>Card</option><option>Bank Transfer</option><option>QR Payment</option></select></label>
<div id="pay-gcash" class="payment-panel"><b>GCash Payment</b><p class="muted">Scan the MRA Hotel demo QR. The reservation is recorded as Pending until payment is confirmed by management.</p><img class="payment-qr-image" src="assets/mra-payment-qr.png" alt="MRA Hotel GCash QR"><p class="qr-caption">GCash reference: MRA-HOTEL-DEMO</p></div>
<div id="pay-qr" class="payment-panel"><b>QR Payment</b><p class="muted">Scan this QR with a compatible payment app. For the school demo, management confirms the payment after booking.</p><img class="payment-qr-image" src="assets/mra-payment-qr.png" alt="MRA Hotel QR Payment"><p class="qr-caption">MRA HOTEL · QR PAYMENT</p></div>
<div id="pay-card" class="payment-panel"><b>Card Payment</b><div class="two"><label>Cardholder Name<input type="text" name="card_name" placeholder="Cardholder name"></label><label>Card Number<input type="text" name="card_number" placeholder="0000 0000 0000 0000"></label></div><div class="two"><label>Expiry<input type="text" name="card_expiry" placeholder="MM/YY"></label><label>CVV<input type="password" name="card_cvv" placeholder="CVV"></label></div></div>
<div id="pay-bank" class="payment-panel"><b>Bank Transfer</b><p class="muted">Demo bank details: MRA Hotel Bank · Account 0000-0000-0000. Enter your reference number in the confirmation step if applicable.</p><label>Transfer Reference<input type="text" name="bank_reference" placeholder="Reference number"></label></div>
<button class="btn full" id="confirmBtn" type="submit" disabled>CONFIRM & BOOK</button>
</form></main>
<script>
const price=<?=json_encode((float)$rt["price_per_night"])?>, cap=<?=json_encode((int)$rt["capacity"])?>;
function updateEstimate(){
 const a=+document.getElementById("adults").value||0,c=+document.getElementById("children").value||0;
 document.getElementById("guestTotal").textContent=`Guests: ${a+c} / ${cap}`;
 const inD=document.getElementById("in").value,outD=document.getElementById("out").value;
 if(!inD||!outD){document.getElementById("duration").textContent="Select your dates to calculate your stay.";document.getElementById("estimate").textContent="Estimated total will appear here.";return;}
 const inT=document.getElementById("inTime").value,outT=document.getElementById("outTime").value;
 if(!inT||!outT){document.getElementById("duration").textContent="Select your dates and times to calculate the stay.";document.getElementById("estimate").textContent="Estimated total will appear here.";return;}
 const start=new Date(`${inD}T${inT}`), end=new Date(`${outD}T${outT}`);
 const hours=(end-start)/3600000, blocks=Math.ceil(hours/24);
 document.getElementById("duration").textContent=hours>0?`Stay duration: ${hours.toFixed(1)} hour${hours===1?"":"s"} · billed as ${blocks} 24-hour stay block${blocks===1?"":"s"}.`:"Check-out must be after check-in.";
 document.getElementById("estimate").textContent=hours>0?`Estimated room total: ₱${(blocks*price).toLocaleString("en-PH",{minimumFractionDigits:2})}`:"";
}
["in","out","inTime","outTime","adults","children"].forEach(id=>document.getElementById(id)?.addEventListener("change",updateEstimate));updateEstimate();

const openCam=document.getElementById("openCam"),video=document.getElementById("video"),canvas=document.getElementById("canvas"),preview=document.getElementById("preview"),file=document.getElementById("id_image");let stream=null;
function showFilePreview(f){
 if(!f)return;
 preview.src=URL.createObjectURL(f); preview.style.display="block";
}
openCam?.addEventListener("click",async()=>{
  // On HTTPS/localhost, use the live camera when available.
  if(window.isSecureContext && navigator.mediaDevices?.getUserMedia){
    try{
      stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"}}});
      video.style.display="block"; video.srcObject=stream;
      openCam.textContent="📷 TAP THE CAMERA TO CAPTURE";
      video.onclick=()=>{
        if(!video.videoWidth)return;
        canvas.width=video.videoWidth; canvas.height=video.videoHeight;
        canvas.getContext("2d").drawImage(video,0,0,canvas.width,canvas.height);
        canvas.toBlob(blob=>{
          const dt=new DataTransfer();
          dt.items.add(new File([blob],"camera-id.jpg",{type:"image/jpeg"}));
          file.files=dt.files; showFilePreview(file.files[0]);
          video.style.display="none"; stream?.getTracks().forEach(t=>t.stop());
          openCam.textContent="📷 RETAKE ID PHOTO";
        },"image/jpeg",.92);
      };
      return;
    }catch(e){}
  }
  // Mobile fallback: capture="environment" asks the phone camera directly.
  file?.click();
});
file?.addEventListener("change",()=>showFilePreview(file.files[0]));
document.getElementById("agreeRules")?.addEventListener("change",e=>document.getElementById("confirmBtn").disabled=!e.target.checked);
const paymentMethod=document.getElementById("paymentMethod");
function updatePaymentPanels(){
 const v=paymentMethod?.value;
 document.querySelectorAll(".payment-panel").forEach(x=>x.style.display="none");
 if(v==="GCash")document.getElementById("pay-gcash").style.display="block";
 if(v==="QR Payment")document.getElementById("pay-qr").style.display="block";
 if(v==="Card")document.getElementById("pay-card").style.display="block";
 if(v==="Bank Transfer")document.getElementById("pay-bank").style.display="block";
}
paymentMethod?.addEventListener("change",updatePaymentPanels);updatePaymentPanels();
</script></body></html>