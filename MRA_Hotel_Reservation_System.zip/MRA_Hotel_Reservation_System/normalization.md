# MRA Hotel — 1NF to 3NF

## 1NF — Atomic values and no repeating groups
Each column contains one value only. There are no Room1/Room2/Room3 repeating columns. One reservation points to one room, while one customer can have many reservation rows.

Example:
Bad: `Reservation(ID, CustomerName, Room1, Room2, Room3)`
Good: `RESERVATION(ReservationID, CustomerID, RoomID, CheckInDate, CheckOutDate, ...)`

## 2NF — Remove partial dependency
The core tables use single-column primary keys, so non-key attributes depend on the whole key. Room type information is separated from ROOM because price, capacity, bed type, and description depend on RoomTypeID.

ROOM(RoomID, RoomNumber, RoomTypeID, FloorNumber, Status)
ROOM_TYPE(RoomTypeID, TypeName, Capacity, PricePerNight, SizeSqm, BedType, Description, Amenities)

## 3NF — Remove transitive dependency
Non-key attributes do not depend on other non-key attributes. Customer information depends on CustomerID. Room type details depend on RoomTypeID. Reservation details depend on ReservationID. Payment details depend on PaymentID/ReservationID.

Final normalized core:
CUSTOMER
ROOM_TYPE
ROOM
RESERVATION
PAYMENT
STAFF

Supporting normalized tables:
USERS, REVIEWS, NOTIFICATIONS, BLOGS, FACILITIES
