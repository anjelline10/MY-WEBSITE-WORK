<?php require "config.php";
$facilities = $pdo->query("SELECT * FROM facilities WHERE status='Active' ORDER BY facility_id")->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Facilities | MRA Hotel</title><link rel="stylesheet" href="assets/style.css"></head><body>
<header class="site-header"><a class="brand" href="index.php"><img class="brand-logo" src="assets/mra-logo.png" alt="MRA Hotel Logo"><span>MRA HOTEL</span></a>
<nav><a href="index.php">Home</a><a href="rooms.php">Rooms</a><a href="amenities.php">Amenities</a><a href="facilities.php">Facilities</a><a href="dining.php">Dining</a><a href="about.php">About Us</a><a href="gallery.php">Gallery</a><a href="reviews.php">Reviews</a><a href="blog.php">Blog</a><a href="location.php">Location</a><a href="contact.php">Contact</a><a href="login.php">Login</a><a href="signup.php">Sign Up</a></nav></header>
<main class="section"><p class="eyebrow">FACILITIES & AMENITIES</p><h1>Experience MRA Hotel beyond your room.</h1>
<p class="lead">Click any facility to see a fuller view, what you can use there, operating hours, guest access, and the experience available to you.</p>
<div class="facility-grid">
<?php foreach($facilities as $f): ?>
<article class="facility-card">
<div class="facility-slider" data-facility="<?= (int)$f['facility_id'] ?>">
<img class="facility-slide active" src="<?=e($f['image_url'])?>" alt="<?=e($f['name'])?>" onerror="this.src='assets/facility-fallback.svg'">
<span class="slide-dot"></span><span class="slide-dot"></span><span class="slide-dot"></span>
</div>
<div class="room-body"><span class="pill"><?=e($f['guest_access'])?></span><h2><?=e($f['name'])?></h2>
<p class="muted"><?=e($f['description'])?></p><p><b>Hours:</b> <?=e($f['operating_hours'])?></p>
<div class="actions"><a class="btn small" href="facility.php?id=<?=$f['facility_id']?>">View Facility</a></div></div>
</article>
<?php endforeach; ?>
</div></main>
<footer><div><b>MRA HOTEL</b><p>Stay. Relax. Experience MRA.</p></div><div><b>Contact</b><p>MRA Hotel Avenue<br>(02) 8123-4567<br>0917-000-0000<br>reservations@mrahotel.com</p></div><div><b>Social</b><p>Facebook · Instagram · TikTok · Messenger</p></div></footer>
<script>
const facilitySlides = {
  1: [
    "https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1572331165267-854da2b10ccc?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1600965962361-9035dbfd1c50?auto=format&fit=crop&w=1200&q=85"
  ],
  2: [
    "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1a?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1599058917212-d750089bc07e?auto=format&fit=crop&w=1200&q=85"
  ],
  3: [
    "https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=1200&q=85"
  ],
  4: [
    "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1445116572660-236099ec97a0?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1200&q=85"
  ],
  5: [
    "https://images.unsplash.com/photo-1506521781263-d8422e82f27a?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1590674899484-d5640e854abe?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1545179605-1296651e9d43?auto=format&fit=crop&w=1200&q=85"
  ],
  6: [
    "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=85",
    "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=1200&q=85"
  ]
};
document.querySelectorAll(".facility-slider").forEach(slider=>{
  const id=slider.dataset.facility, imgs=facilitySlides[id]||[];
  const img=slider.querySelector(".facility-slide");
  let i=0;
  if(imgs.length){img.src=imgs[0];}
  if(imgs.length>1) setInterval(()=>{i=(i+1)%imgs.length; img.style.opacity="0"; setTimeout(()=>{img.src=imgs[i];img.style.opacity="1";},180);},3200);
});
</script></body></html>