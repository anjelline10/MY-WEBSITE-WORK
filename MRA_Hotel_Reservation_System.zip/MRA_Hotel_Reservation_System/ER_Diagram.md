# Simple ER Diagram

```text
CUSTOMER (CustomerID PK)
     1
     |
     | M
RESERVATION (ReservationID PK, CustomerID FK, RoomID FK, StaffID FK)
     |  M
     |          |      \ 1
     |       PAYMENT (PaymentID PK, ReservationID FK)
     |
     M
ROOM (RoomID PK, RoomTypeID FK)
     M
     |
     1
ROOM_TYPE (RoomTypeID PK)

STAFF (StaffID PK)
   1
   |
   M
RESERVATION

CUSTOMER 1 ---- M REVIEWS
CUSTOMER 1 ---- M NOTIFICATIONS
STAFF 1 -------- 1 USER
CUSTOMER 1 ----- 1 USER
```

Relationships:
- Customer 1:M Reservation
- Room Type 1:M Room
- Room 1:M Reservation over time
- Staff 1:M Reservation
- Reservation 1:M Payment
- Customer 1:M Review
- Customer 1:M Notification
