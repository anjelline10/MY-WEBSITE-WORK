<?php require "config.php"; ?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>About Us | MRA Hotel</title><link rel="stylesheet" href="assets/style.css"></head><body>
<header class="site-header"><a class="brand" href="index.php"><img class="brand-logo" src="assets/mra-logo.png" alt="MRA Hotel Logo"><span>MRA HOTEL</span></a><nav><a href="index.php">Home</a><a href="rooms.php">Rooms</a><a href="amenities.php">Amenities</a><a href="facilities.php">Facilities</a><a href="dining.php">Dining</a><a href="about.php">About Us</a><a href="gallery.php">Gallery</a><a href="reviews.php">Reviews</a><a href="blog.php">Blog</a><a href="location.php">Location</a><a href="contact.php">Contact</a><a href="login.php">Login</a><a href="signup.php">Sign Up</a></nav></header>
<main class="section">
<p class="eyebrow">ABOUT MRA HOTEL</p>
<h1>A welcoming stay, thoughtfully designed.</h1>
<div class="two">
<div class="card">
<h2>Our Hotel Story</h2>
<p class="muted">MRA Hotel was created around a simple idea: a hotel stay should feel comfortable from the moment a guest discovers the property until the moment they check out. The hotel combines practical accommodation, warm hospitality, and a straightforward digital reservation experience so guests can choose a room, understand what is included, provide the required identification, and manage their booking with confidence.</p>
<p class="muted">With 210 rooms and a maximum capacity of 620 guests, MRA Hotel offers a range of accommodations for individual travelers, couples, families, business guests, and groups. Every room category is designed with its own space, bed arrangement, amenities, and price so guests can select an option that matches the purpose and length of their stay.</p>
<p class="muted">Beyond the rooms, MRA Hotel provides facilities and services intended to make the stay convenient and enjoyable, including a swimming pool, fitness gym, restaurant, café, parking, housekeeping, Wi-Fi, and a 24/7 front desk. The property also maintains clear booking, payment, identification, and facility policies to support a safe and organized guest experience.</p>
<p class="muted">Our goal is not simply to provide a room. We want every interaction—from reservation to check-in, from using the facilities to check-out—to feel dependable, welcoming, and easy to understand.</p>
<h2>Our Values</h2>
<p class="muted"><b>Comfort</b> · <b>Reliability</b> · <b>Hospitality</b> · <b>Cleanliness</b> · <b>Guest-focused service</b> · <b>Privacy</b></p>
</div>
<div class="card">
<h2>Mission</h2>
<p class="muted">To provide every guest with comfortable accommodation, reliable service, and a welcoming experience through efficient and customer-focused hospitality.</p>
<h2>Vision</h2>
<p class="muted">To become a trusted and preferred hotel destination known for quality service, comfortable accommodations, and memorable guest experiences.</p>
<h2>What We Offer</h2>
<p class="muted">Comfortable rooms across six categories, dining options, swimming pool access, fitness facilities, housekeeping, parking, Wi-Fi, and 24/7 front desk assistance.</p>
<h2>Guest Promise</h2>
<p class="muted">We aim to present clear information before every booking, protect sensitive guest information, and provide a consistent experience throughout the reservation and stay.</p>
</div>
</div>
</main><footer><div><b>MRA HOTEL</b><p>Stay. Relax. Experience MRA.</p></div><div><b>Contact</b><p>MRA Hotel Avenue<br>(02) 8123-4567<br>0917-000-0000<br>reservations@mrahotel.com</p></div><div><b>Social</b><p>Facebook · Instagram · TikTok · Messenger</p></div></footer></body></html>