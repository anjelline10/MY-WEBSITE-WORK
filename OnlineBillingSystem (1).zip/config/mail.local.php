<?php
/**
 * config/mail.local.php
 * -----------------------------------------------------------------
 * TUNAY na SMTP credentials. HUWAG i-commit sa Git/GitHub.
 * Naka-ignore na ito sa .gitignore.
 * -----------------------------------------------------------------
 */
return array(
    'username'   => 'anj765220@gmail.com',
    'password'   => 'arvt ocuz lush bpyo',   // App Password mula sa Google
    'from_email' => 'anj765220@gmail.com',
);
